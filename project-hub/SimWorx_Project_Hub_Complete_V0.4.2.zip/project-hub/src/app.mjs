import {seed} from './demo-data.mjs';
import {ensureManufacturing,projectManufacturingAlerts,saveAssembly} from './manufacturing.mjs';
import {renderManufacturing,handleManufacturingAction,handleManufacturingSubmit} from './manufacturing-ui.mjs';
import {ensureMaterials,materialReadinessV041,createWorkspaceBackup,parseWorkspaceBackup} from './materials-v041.mjs';
import {renderProjectSupply,renderPurchasingV041,renderInventoryV041,handleMaterialsAction,handleMaterialsSubmit,handleMaterialsProof,updateOrderStage} from './materials-ui-v041.mjs';
import {projectBudgetSnapshot,updateProjectBudget,setPurchaseExchangeRate} from './projects-v042.mjs';
import {uid,today,money,number,escapeHtml as e,taskProgress,availableStock,stockMove,receiveOrder,publishUpdate,decideApproval,clientProjection,clientInvite,activeRecords,saveOrganization,saveProject,saveSection,saveTask,setTaskStatus,savePart,saveBomLine,archiveRecord,restoreRecord,predecessorIds,updateTaskPlan,captureBaseline,scheduleSummary,materialReadiness} from './model.mjs';

const APP_VERSION='V0.4.2'; // Every build carries an explicit visible release number.
const STORAGE_KEY='simworx-project-hub-demo-v1'; // Preserve existing V0.1 user changes.
function load(){try{const v=JSON.parse(localStorage.getItem(STORAGE_KEY));if(v?.version===1)return v;}catch{}return seed()}
let data=load();
ensureManufacturing(data);
ensureMaterials(data);
const ui={page:'overview',project:'p1',projectTab:'structure',dept:'All',taskView:'board',clientOrg:'noah',clientProject:'p1',clientTab:'updates',customerDetail:null,query:'',modal:null,ganttOffset:0,mfgAssemblyId:null,mfgTab:'overview',mfgEditor:null,materialPO:null,materialOrderEditor:false,materialPrefill:null,procurementProject:'all',materialOrderProject:null,materialEditOccurrence:null,showProjectList:false,partReturnProject:null};
const persist=()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data));}catch{toast('Local storage is full; changes may not persist.',true)}};
const findProject=id=>data.projects.find(x=>x.id===id);
const findOrg=id=>data.organizations.find(x=>x.id===id);
const findPart=id=>data.parts.find(x=>x.id===id);
const active=activeRecords;
const allActiveProjects=()=>active(data.projects).filter(p=>!findOrg(p.orgId)?.archivedAt);
const activeOrgProjects=id=>allActiveProjects().filter(p=>p.orgId===id);
const projectOrg=p=>findOrg(p.orgId);
const day=s=>{if(!s)return 'Not set';const d=new Date(String(s).slice(0,10)+'T12:00:00Z');return Number.isNaN(+d)?String(s):d.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})};
const pct=n=>Math.max(0,Math.min(100,Math.round(Number(n)||0)));
const stateColor=s=>/done|received|approved|complete/i.test(s)?'green':/blocked|overdue|rejected/i.test(s)?'red':/progress|inspection|awaiting|pending|ready/i.test(s)?'amber':/design|draft/i.test(s)?'purple':'blue';
const badge=(s,c=stateColor(s))=>`<span class="pill ${c}">${e(s)}</span>`;
const meter=(value,variant='')=>`<div class="meter ${variant}"><i style="width:${pct(value)}%"></i></div>`;
const chip=(org)=>`<span class="customer-mini" style="background:${e(org?.accent||'#6f57d9')}">${e(org?.logo||'?')}</span>`;
const glyph=kind=>`<svg viewBox="0 0 120 95" fill="none" aria-hidden="true"><ellipse cx="60" cy="77" rx="49" ry="7" fill="#fff" opacity=".11"/><path d="M18 63V43l15-16h54l15 16v20H18Z" stroke="#9cc7f1" stroke-width="3" fill="#2d5173" opacity=".95"/><path d="M33 27v36M87 27v36M18 44h84M50 27v37M70 27v37" stroke="#a9ccf5" stroke-width="2"/><path d="M22 65h76M29 16l9-7h44l9 7" stroke="#e2f1ff" stroke-width="2"/>${kind==='motion'?'<path d="m21 80 18-12h42l18 12M36 77v-9M84 77v-9" stroke="#e9d5ff" stroke-width="3"/>':''}</svg>`;
const heroArt=()=>`<svg viewBox="0 0 420 320" fill="none" aria-hidden="true"><g stroke="#b6d6f6" stroke-width="2" opacity=".7"><ellipse cx="220" cy="238" rx="165" ry="31"/><path d="M75 220V130l50-68h190l50 68v90H75Z" fill="#3574b0" fill-opacity=".1"/><path d="M125 62v159M315 62v159M75 130h290M173 62v161M268 62v161"/><path d="M78 217h285M77 174h285M125 62l48 68m142-68-47 68"/><path d="M74 219 42 241m322-23 33 23m-257-11 0 45m143-45 0 45"/></g><g fill="#87bef0" opacity=".25"><rect x="143" y="146" width="56" height="27" rx="4"/><rect x="221" y="146" width="56" height="27" rx="4"/><circle cx="171" cy="160" r="10"/><circle cx="249" cy="160" r="10"/></g></svg>`;
const icons={overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',projects:'<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M7 6V4h5l2 2"/>',tasks:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 12 3 3 6-7"/>',purchasing:'<path d="M4 5h2l2 11h11l2-8H7M10 21h.01M18 21h.01"/>',inventory:'<path d="m12 2 9 5-9 5-9-5 9-5Zm-9 5v10l9 5 9-5V7M12 12v10"/>',customers:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm10-1a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.87"/>',client:'<path d="M4 4h16v16H4zM4 9h16M9 20V9"/>',finance:'<path d="M3 3v18h18M7 15l4-4 3 2 5-7"/>',reports:'<path d="M4 20V10m5 10V4m5 16v-7m5 7V7M2 20h20"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a2 2 0 0 0 .4 2.2l.1.1-2 2-1-.6a2 2 0 0 0-2.2-.1l-.3.2-.4 1.2h-3l-.4-1.2a2 2 0 0 0-2.2-.1l-1 .6-2-2 .7-1a2 2 0 0 0-.2-2.2l-1.2-.5v-3l1.2-.4a2 2 0 0 0 .2-2.2l-.7-1 2-2 1 .7a2 2 0 0 0 2.2-.2l.4-1.2h3l.4 1.2a2 2 0 0 0 2.2.2l1-.7 2 2-.7 1a2 2 0 0 0-.1 2.2l1.2.4v3z"/>',plus:'<path d="M12 5v14M5 12h14"/>',search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4"/>',moon:'<path d="M20 15A8 8 0 0 1 9 4 8 8 0 1 0 20 15Z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',chevron:'<path d="m9 18 6-6-6-6"/>',down:'<path d="m6 9 6 6 6-6"/>',check:'<path d="m5 12 4 4L19 6"/>',close:'<path d="M18 6 6 18M6 6l12 12"/>',external:'<path d="M13 5h6v6M19 5l-9 9M19 13v6H5V5h6"/>',file:'<path d="M6 2h9l5 5v15H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2ZM14 2v6h6"/>',message:'<path d="M20 16a3 3 0 0 1-3 3H7l-4 3V6a3 3 0 0 1 3-3h11a3 3 0 0 1 3 3v10Z"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',shield:'<path d="M12 2 3 6v6c0 6 4 9 9 10 5-1 9-4 9-10V6l-9-4Z"/><path d="m8 12 3 3 5-6"/>',warehouse:'<path d="m3 9 9-6 9 6v12H3V9Zm5 12v-9h8v9M3 9h18"/>',more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',arrow:'<path d="M4 12h16m-7-7 7 7-7 7"/>',filter:'<path d="M4 7h16M7 12h10M10 17h4"/>',refresh:'<path d="M4 11a8 8 0 0 1 13-6l3 3M20 4v4h-4M20 13a8 8 0 0 1-13 6l-3-3m0 4v-4h4"/>',upload:'<path d="M12 16V3m-5 5 5-5 5 5M4 16v4h16v-4"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>'};
const ico=(n,size=18)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[n]||icons.file}</svg>`;
const button=(label,action='',variant='',attr='')=>`<button type="button" class="btn ${variant}" data-action="${action}" ${attr}>${label}</button>`;
const head=(title,desc,actions='')=>`<div class="page-heading"><div><h1>${e(title)}</h1><p>${e(desc)}</p></div><div class="heading-actions">${actions}</div></div>`;
const card=(title,body,actions='',subtitle='')=>`<div class="card"><div class="card-head"><div><h2>${e(title)}</h2>${subtitle?`<div class="card-sub">${e(subtitle)}</div>`:''}</div>${actions}</div>${body}</div>`;
const projectSelect=(selected,attr='')=>`<select class="filter-select" ${attr}>${allActiveProjects().map(p=>`<option value="${e(p.id)}" ${selected===p.id?'selected':''}>${e(p.code)} · ${e(p.name)}</option>`).join('')}</select>`;
const customerSelect=(selected,attr='')=>`<select class="filter-select" ${attr}>${active(data.organizations).map(o=>`<option value="${e(o.id)}" ${selected===o.id?'selected':''}>${e(o.name)}</option>`).join('')}</select>`;
const projectTitle=p=>`<div class="project-cell"><div class="project-glyph ${p.template==='DA62'?'diamond':p.template==='Motion Upgrade'?'motion':'king'}">${glyph(p.template==='Motion Upgrade'?'motion':'')}</div><div><div class="project-title">${e(p.name)}</div><div class="subtle mono">${e(p.code)}</div></div></div>`;
const audit=(action,detail,actor='Sim-Worx Admin')=>data.audit.unshift({id:uid('audit'),action,detail,actor,at:new Date().toISOString()});
const notify=text=>data.notifications.unshift({id:uid('note'),text,date:today(),read:false});
let toastTimer;
function toast(msg,error=false){const old=document.querySelector('.toast');if(old)old.remove();const t=document.createElement('div');t.className=`toast ${error?'error':''}`;t.textContent=msg;document.body.appendChild(t);clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.remove(),4100)}
function render(){
  const labels={overview:'Dashboard',projects:'Projects',assemblies:'Component & assemblies',tasks:'Production jobs',purchasing:'Purchasing',inventory:'Inventory',customers:'Customers & access',client:'Customer portal',finance:'Project financials',reports:'Reports & progress',settings:'Settings'};
  const nav=[['overview','Overview'],['projects','Projects'],['assemblies','Assemblies & components'],['tasks','Workshop & office'],['purchasing','Purchasing'],['inventory','Inventory'],['customers','Customers & access'],['client','Client portal preview'],['finance','Financials'],['reports','Reports'],['settings','Settings']];
  const navHtml=nav.map(([id,label],idx)=>`${idx===0||idx===4||idx===7||idx===8?`<div class="nav-group-label">${idx===0?'WORKSPACE':idx===4?'OPERATIONS':idx===7?'COLLABORATION':'CONTROL & INSIGHT'}</div>`:''}<button class="nav-link ${ui.page===id?'active':''}" data-action="nav" data-id="${id}" aria-current="${ui.page===id?'page':'false'}">${ico(id)}<span>${label}</span>${id==='client'?'<span class="count-dot">↗</span>':''}</button>`).join('');
  const title=labels[ui.page]||'Project Hub';
  document.body.classList.toggle('dark',data.settings.theme==='dark');
  document.getElementById('app').innerHTML=`<div class="app-shell">
    <aside class="sidebar"><div class="brand"><div class="brand-gem">${ico('warehouse',23)}</div><div class="brand-name">SIM-WORX<span>PROJECT HUB</span></div></div><nav>${navHtml}</nav><div class="sidebar-bottom"><div class="workspace-mark"><div class="avatar">SW</div><div><b>Sim-Worx Team</b><small>Local demonstration</small></div></div></div></aside>
    <div class="main"><header class="topbar"><div><div class="top-title">${e(title)}</div><div class="top-sub">Plan, build, deliver — all in one place</div></div><div class="top-actions"><span class="version-chip" aria-label="Application version ${APP_VERSION}" title="Sim-Worx Project Hub · ${APP_VERSION}">${APP_VERSION}</span><span class="demo-ribbon">DEMO · NOT LIVE</span><label class="top-search">${ico('search')}<input id="global-search" placeholder="Search projects..." autocomplete="off" aria-label="Search projects" /></label><button class="circle-btn" data-action="theme" aria-label="Toggle colour theme" title="Light / dark mode">${ico(data.settings.theme==='light'?'moon':'sun')}</button><button class="circle-btn" data-action="notifications" aria-label="Notifications" title="Notifications">${ico('bell')}</button><div class="avatar" title="Sim-Worx Administrator">SW</div></div></header>
    <main class="content">${pageContent()}</main></div></div>${ui.modal?modalContent():''}`;
  bindGlobalSearch();
}
function bindGlobalSearch(){const el=document.getElementById('global-search');if(!el)return;el.value=ui.query;el.addEventListener('keydown',ev=>{if(ev.key==='Enter'){const q=el.value.trim().toLowerCase();const p=data.projects.find(p=>`${p.name} ${p.code} ${projectOrg(p)?.name}`.toLowerCase().includes(q));if(p){ui.project=p.id;ui.page='projects';ui.projectTab='structure';ui.query='';render();}else toast('No matching project found',true)}})}
function pageContent(){switch(ui.page){case 'overview':return overview();case 'projects':return projectsPage();case 'assemblies':return manufacturingPage();case 'tasks':return tasksPage();case 'purchasing':return renderPurchasingV041(data,ui);case 'inventory':return renderInventoryV041(data,ui);case 'customers':return customersPage();case 'client':return clientPage();case 'finance':return financePage();case 'reports':return reportsPage();case 'settings':return settingsPageV041();default:return overview()}}
function overview(){
  const runningProjects=allActiveProjects().filter(p=>p.status!=='Delivered');const avg=Math.round(runningProjects.reduce((a,p)=>a+taskProgress(p.id,active(data.tasks)),0)/(runningProjects.length||1));
  const pending=data.approvals.filter(a=>a.status==='Pending'&&!a.archivedAt&&allActiveProjects().some(p=>p.id===a.projectId)).length,blocked=active(data.tasks).filter(t=>t.status==='Blocked'&&allActiveProjects().some(p=>p.id===t.projectId)).length;
  const kpis=[['Active projects',runningProjects.length,'projects','Across '+data.organizations.length+' customers'],['Internal progress',avg+'%','reports','Weighted job status snapshot'],['Open production jobs',active(data.tasks).filter(t=>!['Done','Cancelled'].includes(t.status)&&allActiveProjects().some(p=>p.id===t.projectId)).length,'tasks','Office & workshop tasks'],['Client approvals',pending,'shield','Decisions awaiting clients']];
  const kpiHtml=kpis.map(([label,value,icon,note])=>`<div class="kpi"><div><div class="kpi-label">${e(label)}</div><div class="kpi-value mono">${e(value)}</div><div class="kpi-note">${e(note)}</div></div><div class="kpi-icon">${ico(icon,23)}</div></div>`).join('');
  const rows=allActiveProjects().map(p=>`<tr><td class="clickable" data-action="project-open" data-id="${p.id}">${projectTitle(p)}</td><td><div style="display:flex;gap:7px;align-items:center">${chip(projectOrg(p))}<b>${e(projectOrg(p).name)}</b></div></td><td><div class="progress-line">${meter(taskProgress(p.id,data.tasks))}<span class="mono">${taskProgress(p.id,data.tasks)}%</span></div></td><td>${badge(p.status)}</td><td class="subtle">${day(p.due)}</td><td>${button(ico('chevron'),'project-open','small',`data-id="${p.id}" aria-label="Open ${e(p.name)}"`)}</td></tr>`).join('');
  const spotlight=allActiveProjects()[0];
  const pipelines=[['Engineering','Office',active(data.tasks).filter(t=>t.department==='Office'&&t.status!=='Done').length,'projects'],['Workshop floor','Workshop',active(data.tasks).filter(t=>t.department==='Workshop'&&t.status!=='Done').length,'inventory'],['Procurement','Purchasing',active(data.tasks).filter(t=>t.department==='Purchasing'&&t.status!=='Done').length,'purchasing'],['Quality control','Quality',active(data.tasks).filter(t=>t.department==='Quality'&&t.status!=='Done').length,'shield']];
  return head('Good morning, Sim-Worx','Your manufacturing and delivery overview for '+day(today()),button(`${ico('plus')} New project`,'open-project-modal','primary'))+
  `<div class="kpis">${kpiHtml}</div><div class="grid-main"><div class="column">${card('Project portfolio',`<div class="table-wrap"><table class="table"><thead><tr><th>Project</th><th>Customer</th><th>Progress</th><th>Status</th><th>Delivery</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`,button('View projects','nav','small',`data-id="projects"`),'Live overview from local demo records')}
  ${card('Department workload',`<div class="card-body" style="padding-top:0">${pipelines.map(([title,dept,count,icon])=>`<div class="pipeline-item"><div class="pipe-icon">${ico(icon)}</div><div class="pipe-main"><strong>${title}</strong><small>${dept} team · outstanding actions</small></div><span class="pipe-count mono">${count}</span>${button(ico('chevron'),'department-open','small',`data-id="${dept}"`)}</div>`).join('')}</div>`,'','See who needs to do what next')}</div>
  <div class="column"><div class="hero-card"><div class="hero-content"><div class="eyebrow">PROJECT SPOTLIGHT · ${e(spotlight?.code||"CREATE A PROJECT")}</div><h2>${e(spotlight?.name||"Your next simulator build")}</h2><p>From engineering drawings to a finished simulator. Track every build stage in one connected workspace.</p>${spotlight?button('Open project '+ico('arrow'),'project-open','primary',`data-id="${spotlight.id}"`):button('Create project','open-project-modal','primary')}</div><div class="hero-art">${heroArt()}</div></div>
  ${card('Needs your attention',`<div class="card-body" style="padding-top:0"><div class="pipeline-item"><div class="pipe-icon">${ico('shield')}</div><div class="pipe-main"><strong>${pending} customer approvals waiting</strong><small>Drawings and milestone sign-offs</small></div>${badge('Action needed','amber')}</div><div class="pipeline-item"><div class="pipe-icon">${ico('clock')}</div><div class="pipe-main"><strong>${blocked} blocked production job${blocked===1?'':'s'}</strong><small>Check materials and dependencies</small></div>${badge('Review','red')}</div><div class="pipeline-item"><div class="pipe-icon">${ico('inventory')}</div><div class="pipe-main"><strong>${active(data.parts).filter(p=>availableStock(p)<=p.min).length} parts near reorder level</strong><small>Available stock vs minimum</small></div>${badge('Monitor','amber')}</div></div>`)}
  ${card('Recent activity',`<div class="card-body" style="padding-top:0"><div class="activity">${data.audit.slice(0,4).map(a=>`<div class="activity-row"><strong>${e(a.action)}</strong><span>${e(a.detail)}<br>${e(a.actor)} · ${day(a.at)}</span></div>`).join('')}</div></div>`)}</div></div>`;
}
function manufacturingPage(){const p=findProject(ui.project)&&!findProject(ui.project).archivedAt?findProject(ui.project):allActiveProjects()[0];if(!p)return head('Assemblies & components','Create a simulator project first.');ui.project=p.id;return head('Assemblies & components','Revision-gated parts and subassemblies for each simulator project.')+`<div class="toolbar" style="margin-bottom:12px"><span class="subtle">Select simulator project</span>${projectSelect(p.id,'data-filter="mfgProject"')}</div>`+renderManufacturing(data,ui,p.id);}

function projectsPage(){
 const all=allActiveProjects(),original=findProject(ui.project),p=original&&!original.archivedAt?original:all[0];
 if(p)ui.project=p.id;
 const rows=all.map(x=>'<tr><td>'+projectTitle(x)+'</td><td>'+e(projectOrg(x)?.name||'Customer')+'</td>'+
  '<td>'+badge(x.status)+'</td><td>'+taskProgress(x.id,active(data.tasks))+'%</td><td>'+day(x.due)+'</td>'+
  '<td><div class="row-actions">'+button('Open','project-open','small','data-id="'+x.id+'"')+
  button('Edit','edit-project','small','data-id="'+x.id+'"')+
  button('Archive','archive-record','small danger','data-kind="projects" data-id="'+x.id+'"')+'</div></td></tr>').join('');
 const chooser=p?'<div class="v42-project-switch"><div><span class="v42-eyebrow">SELECT PROJECT</span>'+
  projectSelect(p.id,'data-filter="v42-project" aria-label="Select project"')+'</div><div class="v42-project-actions">'+
  button(ui.showProjectList?'Hide portfolio':'Browse all projects','v42-toggle-project-list','small')+
  button('New project','open-project-modal','small primary')+'</div></div>':'';
 const list=ui.showProjectList?card('All active projects',
  '<div class="table-wrap"><table class="table"><thead><tr><th>Project</th><th>Customer</th><th>Status</th>'+
  '<th>Progress</th><th>Due</th><th>Manage</th></tr></thead><tbody>'+rows+'</tbody></table></div>',
  '','Switch projects or edit their details'):'';
 return '<div class="v42-project-page">'+head('Projects','Focus on one project; browse the portfolio only when needed.')+
  chooser+list+(p?projectDetail(p):'<div class="empty">Create a project to begin.</div>')+'</div>';
}
function projectDetail(p){
 const org=projectOrg(p),b=projectBudgetSnapshot(data,p.id);
 const mfg=projectManufacturingAlerts(data,p.id).length,shortage=materialReadinessV041(data,p.id).filter(x=>x.toSource>0).length;
 const top=[['structure','Work breakdown'],['register','Work register'],['schedule','Gantt'],
  ['assembly','Assemblies'],['procurement','Procurement'],['budget','Budget']];
 const extras=[['bom','Legacy BOM'],['materials','Legacy forecast'],['documents','Documents'],['publishing','Client publishing']];
 const extraSelected=extras.some(pair=>pair[0]===ui.projectTab);
 const content={structure:projectStructure(p),register:projectRegister(p),schedule:projectSchedule(p),
  assembly:ui.projectTab==='assembly'?renderManufacturing(data,ui,p.id):'',
  procurement:ui.projectTab==='procurement'?renderProjectSupply(data,ui,p.id):'',
  budget:ui.projectTab==='budget'?projectBudgetPage(p):'',
  bom:projectBom(p),materials:projectMaterials(p),documents:projectDocuments(p),publishing:projectPublishing(p)};
 const meta='<div class="v42-project-summary"><div class="v42-project-identity"><span class="v42-eyebrow">'+
  e(p.code)+' · '+e(org?.name||'Customer')+'</span><h2>'+e(p.name)+'</h2><p>'+e(p.description||'No description')+'</p>'+
  '<div class="v42-project-mini">'+badge(p.status)+'<span>Lead: <b>'+e(p.lead||'Unassigned')+'</b></span>'+
  '<span>Due: <b>'+day(p.due)+'</b></span><span>Progress: <b>'+taskProgress(p.id,active(data.tasks))+'%</b></span>'+
  button('Edit details','edit-project','small','data-id="'+p.id+'"')+'</div></div>'+
  '<div class="v42-summary-budget"><span class="v42-eyebrow">BUDGET REMAINING</span>'+
  '<strong class="'+(b.overBudget?'danger-text':'')+'">'+money(b.headroom)+'</strong>'+
  '<span>'+money(b.forecast)+' forecast / '+money(b.budget)+' allocated</span>'+
  '<div class="v42-budget-track"><span style="width:'+Math.min(100,Math.max(0,b.percent))+'%;background:'+
  (b.overBudget?'#d94f58':'#6554d9')+'"></span></div>'+button('Manage budget','project-tab','small','data-id="budget"')+'</div></div>';
 const attention=shortage||mfg?'<div class="v42-attention">'+
  (shortage?'<span>'+shortage+' material sourcing shortfall(s) '+button('Open procurement','project-tab','small','data-id="procurement"')+'</span>':'')+
  (mfg?'<span>'+mfg+' engineering blocker(s) '+button('Review assemblies','project-tab','small','data-id="assembly"')+'</span>':'')+
  '</div>':'';
 const tabs='<div class="v42-primary-tabs">'+top.map(pair=>
  '<button type="button" data-action="project-tab" data-id="'+pair[0]+'" class="'+(ui.projectTab===pair[0]?'active':'')+'">'+pair[1]+'</button>').join('')+
  '<select data-filter="v42-project-extra" aria-label="Additional project sections" class="'+(extraSelected?'active':'')+'">'+
  '<option value="">More...</option>'+extras.map(pair=>'<option value="'+pair[0]+'" '+(ui.projectTab===pair[0]?'selected':'')+'>'+pair[1]+'</option>').join('')+
  '</select></div>';
 return '<div id="project-detail" class="v42-project-detail">'+meta+attention+
  '<div class="card v42-project-work">'+tabs+'<div class="v42-project-content">'+(content[ui.projectTab]||content.structure)+'</div></div></div>';
}
function projectBudgetPage(p){
 const b=projectBudgetSnapshot(data,p.id);
 const stats=[['Project budget',money(b.budget)],['Actual & received',money(b.actual)],
  ['Open commitments',money(b.commitment)],[b.overBudget?'Forecast overrun':'Budget remaining',money(b.headroom)]];
 const tiles=stats.map(([label,value])=>'<div class="v42-budget-tile"><small>'+label+'</small><strong>'+value+'</strong></div>').join('');
 const conversions=b.unconverted.map(o=>'<form data-form="v42-exchange" class="v42-exchange-row">'+
  '<input type="hidden" name="orderId" value="'+e(o.id)+'"><span>'+e(o.code)+' · '+e(o.currency)+'</span>'+
  '<label>EUR per 1 '+e(o.currency)+'<input name="eurExchangeRate" type="number" min="0.000001" step="any" required placeholder="Rate"></label>'+
  '<button class="btn small" type="submit">Apply rate</button></form>').join('');
 const form='<form data-form="v42-budget" class="v42-budget-editor"><input type="hidden" name="projectId" value="'+e(p.id)+'">'+
  '<label>Allocated budget (€)<input name="budget" type="number" min="0" step="0.01" required value="'+e(b.budget)+'"></label>'+
  '<label>Previously recorded costs (€)<input name="spent" type="number" min="0" step="0.01" required value="'+e(b.legacySpent)+'"></label>'+
  '<label>Existing/manual commitments (€)<input name="committed" type="number" min="0" step="0.01" required value="'+e(b.legacyCommitted)+'"></label>'+
  '<button class="btn primary" type="submit">Save budget</button></form>';
 const breakdown=[['Previously recorded costs',b.legacySpent],['New PO goods received',b.poReceived],
  ['Existing/manual commitments',b.legacyCommitted],['New PO balances outstanding',b.poOpen]];
 return '<section class="v42-budget-workspace"><div class="v42-budget-intro"><div><h3>Project budget control</h3>'+
  '<p>Set the project allowance and follow costs against it.</p></div>'+badge(b.unconverted.length?'FX rate needed':b.overBudget?'Over budget':'Within budget',b.unconverted.length?'amber':b.overBudget?'red':'green')+'</div>'+
  '<div class="v42-budget-grid">'+tiles+'</div><div class="v42-budget-track"><span style="width:'+
  Math.min(100,Math.max(0,b.percent))+'%;background:'+(b.overBudget?'#d94f58':'#6554d9')+'"></span></div>'+
  '<p class="v41-caption">'+b.percent+'% of the allocated budget forecast to be used.</p>'+form+
  '<div class="v42-cost-breakdown"><h4>Forecast cost breakdown</h4>'+
  breakdown.map(([label,value])=>'<div><span>'+label+'</span><b>'+money(value)+'</b></div>').join('')+
  '<div class="v42-budget-total"><span>Forecast cost</span><b>'+money(b.forecast)+'</b></div></div>'+
  (conversions?'<div class="v42-budget-warning"><strong>Foreign-currency orders excluded until converted to EUR</strong>'+conversions+'</div>':'')+
  '<p class="v41-caption">Previously recorded costs and commitments are manually maintained. New purchase orders are counted separately; receipts move PO costs from outstanding commitments to actuals without adding them twice. Legacy imported orders are excluded because they may already be in the manual totals. Not an accounting ledger.</p></section>';
}
function projectStructure(p){
 const sections=active(data.sections).filter(s=>s.projectId===p.id);
 const roots=sectionId=>active(data.tasks).filter(t=>t.sectionId===sectionId&&!t.parentId);
 const renderTree=(t,depth=0,visited=new Set())=>{
   if(visited.has(t.id)||depth>12)return '';
   const next=new Set([...visited,t.id]);const children=active(data.tasks).filter(x=>x.parentId===t.id);
   const dependency=t.blockedBy?data.tasks.find(x=>x.id===t.blockedBy):null;
   return `<div class="wbs-tree-node" style="--depth:${Math.min(depth,8)}"><div class="task-item"><button class="task-bullet ${t.status==='Done'?'done':''}" data-action="toggle-task" data-id="${t.id}" title="Toggle completion">${t.status==='Done'?ico('check',12):''}</button><div class="details"><strong>${e(t.title)}</strong><small>${e(t.assignee)} · Due ${day(t.due)}${dependency?` · After: ${e(dependency.title)}`:''}</small></div><span class="tag ${e(t.department.toLowerCase())}">${e(t.department)}</span>${badge(t.status)}<div class="row-actions">${button('Edit','edit-task','small',`data-id="${t.id}"`)}${button('Sub-job','add-subtask','small',`data-id="${t.id}"`)}${button(ico('close',13),'archive-record','small danger',`data-kind="tasks" data-id="${t.id}" title="Archive job" aria-label="Archive ${e(t.title)}"`)}</div></div>${children.map(c=>renderTree(c,depth+1,next)).join('')}</div>`;
 };
 return `<div class="toolbar"><div class="subtle">WBS · Project → Sections → Jobs → Sub-jobs</div><div class="spacer"></div>${button('Export WBS CSV','export-wbs','small',`data-id="${p.id}"`)}${button(`${ico('plus')} Section`,'add-section','small',`data-project="${p.id}"`)}${button(`${ico('plus')} Job`,'open-task-modal','small primary',`data-project="${p.id}"`)}</div><div class="hierarchy">${sections.map((sec,i)=>{const tasks=active(data.tasks).filter(t=>t.sectionId===sec.id);const done=tasks.length?Math.round(tasks.filter(t=>t.status==='Done').length/tasks.length*100):0;return `<div class="hierarchy-section"><div class="hierarchy-section-title"><div class="wbs-section-label">${ico('projects')}<span class="wbs-code">${i+1}.0</span>${e(sec.name)} <span class="subtle">${tasks.length} jobs</span></div><div class="row-actions">${meter(done)}<span>${done}%</span>${button('Edit','edit-section','small',`data-id="${sec.id}"`)}${button(ico('close',13),'archive-record','small danger',`data-kind="sections" data-id="${sec.id}" title="Archive section" aria-label="Archive ${e(sec.name)}"`)}</div></div><div class="hierarchy-tasks">${tasks.length?roots(sec.id).map(t=>renderTree(t)).join(''):'<div class="subtle" style="padding:12px">No jobs in this section yet.</div>'}</div></div>`}).join('')||'<div class="empty">Add a section to begin the project work breakdown.</div>'}</div>`;
}

// V0.3 planning views use the *same internal jobs* as the workshop board.
const DAY=86400000;
const asUtc = date => Date.parse(`${date}T12:00:00Z`);
const shiftDate = (date,offset) => new Date(asUtc(date)+offset*DAY).toISOString().slice(0,10);
function flattenedProjectJobs(p){
 const jobs=active(data.tasks).filter(t=>t.projectId===p.id),sections=active(data.sections).filter(s=>s.projectId===p.id);
 const output=[];
 const traverse=(t,code,depth,seen=new Set())=>{if(seen.has(t.id)||depth>12)return;output.push({task:t,code,depth});const next=new Set([...seen,t.id]);jobs.filter(child=>child.parentId===t.id).forEach((child,i)=>traverse(child,`${code}.${i+1}`,depth+1,next));};
 sections.forEach((sec,i)=>{output.push({section:sec,code:`${i+1}.0`,depth:0});jobs.filter(t=>t.sectionId===sec.id&&(!t.parentId||!jobs.some(x=>x.id===t.parentId))).forEach((t,k)=>traverse(t,`${i+1}.${k+1}`,0));});
 return output;
}
function projectRegister(p){
 const rows=flattenedProjectJobs(p);
 const statusOptions=['Backlog','Ready','In progress','Blocked','Inspection','Done','Cancelled'];
 const departments=['Office','Workshop','Purchasing','Quality'];
 const selector=(task,field,values)=>`<select class="sheet-control" data-inline-task="${e(task.id)}" data-field="${field}" aria-label="${field} for ${e(task.title)}">${values.map(v=>`<option value="${e(v)}" ${task[field]===v?'selected':''}>${e(v)}</option>`).join('')}</select>`;
 return `<div class="planning-intro"><div><strong>Engineering work register</strong><p>Edit cells directly, or open any job for predecessor and hierarchy settings. Changes remain in this browser demo.</p></div><div class="row-actions">${button('Export WBS CSV','export-wbs','small',`data-id="${p.id}"`)}${button(`${ico('plus')} New job`,'open-task-modal','small primary',`data-project="${p.id}"`)}</div></div><div class="sheet-scroll"><table class="work-sheet"><thead><tr><th>WBS</th><th style="min-width:240px">Job / Work package</th><th>Owner</th><th>Department</th><th>Start</th><th>Finish</th><th>Status</th><th>Priority</th><th>Dependencies</th><th></th></tr></thead><tbody>${rows.map(row=>{
 if(row.section)return `<tr class="sheet-section"><td class="mono">${e(row.code)}</td><td colspan="9">${ico('projects',13)} ${e(row.section.name)}</td></tr>`;
 const t=row.task;const predecessors=predecessorIds(t).map(id=>data.tasks.find(x=>x.id===id)?.title||id).join(', ');
 return `<tr><td class="mono sheet-wbs">${e(row.code)}</td><td><div class="sheet-title" style="padding-left:${row.depth*15}px">${row.depth?'↳ ':''}<strong>${e(t.title)}</strong></div></td><td><input class="sheet-control owner" data-inline-task="${e(t.id)}" data-field="assignee" aria-label="Owner for ${e(t.title)}" value="${e(t.assignee)}"></td><td>${selector(t,'department',departments)}</td><td><input type="date" class="sheet-control date" data-inline-task="${e(t.id)}" data-field="start" aria-label="Start date for ${e(t.title)}" value="${e(t.start||'')}"></td><td><input type="date" class="sheet-control date" data-inline-task="${e(t.id)}" data-field="due" aria-label="Finish date for ${e(t.title)}" value="${e(t.due||'')}"></td><td>${selector(t,'status',statusOptions)}</td><td>${selector(t,'priority',['Normal','High','Critical'])}</td><td title="${e(predecessors)}" class="sheet-deps">${predecessors?e(predecessors):'<span class="subtle">—</span>'}</td><td>${button('Open','edit-task','small',`data-id="${e(t.id)}"`)}</td></tr>`;
 }).join('')}</tbody></table></div><div class="planning-foot">${rows.filter(x=>x.task).length} jobs · A recorded date is a manual plan, not an automatically generated promise. You can still export this WBS to Excel.</div>`;
}
function projectSchedule(p){
 const summary=scheduleSummary(data,p.id),jobs=flattenedProjectJobs(p);
 const anchor=shiftDate(today(),-14+ui.ganttOffset*28);const WEEKS=16;const spanDays=WEEKS*7;
 const end=shiftDate(anchor,spanDays),ax=asUtc(anchor),width=100;
 const xPos=date=>100*((asUtc(date)-ax)/DAY)/spanDays;
 const weeks=Array.from({length:WEEKS},(_,i)=>shiftDate(anchor,i*7));
 const todayX=xPos(today());
 const header=`<div class="gantt-row gantt-head"><div class="gantt-label">WBS / Department job</div><div class="gantt-axis">${weeks.map(w=>`<div>${day(w).replace(/,? \d{4}/,'')}</div>`).join('')}</div></div>`;
 const content=jobs.map(row=>{
  if(row.section)return `<div class="gantt-row gantt-section"><div class="gantt-label">${e(row.code)} · ${e(row.section.name)}</div><div class="gantt-grid"></div></div>`;
  const t=row.task,start=t.start||'',due=t.due||'',base=p.baseline?.jobs?.[t.id],deps=predecessorIds(t),conflict=summary.conflicts.some(x=>x.jobId===t.id);
  let bar='';
  if(start&&due){const left=Math.max(0,xPos(start)),right=Math.min(100,xPos(shiftDate(due,1)));if(right>left)bar=`<div class="gantt-bar ${t.status==='Done'?'complete':''} ${conflict?'conflict':''}" title="${e(t.title)}: ${day(start)} – ${day(due)}" style="left:${left}%;width:${Math.max(0.5,right-left)}%"></div>`;}
  else if(due){const mark=xPos(due);if(mark>=0&&mark<=100)bar=`<div class="gantt-marker" style="left:${mark}%" title="Finish ${day(due)} — add a start date"></div>`;}
  let baseline='';if(base?.start&&base?.due){const left=Math.max(0,xPos(base.start)),right=Math.min(100,xPos(shiftDate(base.due,1)));if(right>left)baseline=`<div class="gantt-baseline" style="left:${left}%;width:${Math.max(0.5,right-left)}%" title="Original baseline ${day(base.start)}–${day(base.due)}"></div>`;}
  return `<div class="gantt-row"><div class="gantt-label gantt-job" style="padding-left:${14+row.depth*17}px"><span class="mono">${e(row.code)}</span><button data-action="edit-task" data-id="${e(t.id)}" title="Edit job plan">${e(t.title)}</button><small>${e(t.department)}${deps.length?` · ${deps.length} predecessor${deps.length>1?'s':''}`:''}</small></div><div class="gantt-grid" data-action="edit-task" data-id="${e(t.id)}" title="Edit ${e(t.title)}">${baseline}${bar}${!start?'<span class="gantt-unscheduled">Plan start</span>':''}${todayX>=0&&todayX<=100?`<span class="gantt-today" style="left:${todayX}%"></span>`:''}</div></div>`;
 }).join('');
 const alerts=[...summary.conflicts.map(x=>`<div class="plan-warning">${ico('clock',15)} <b>Dependency clash</b> · ${e(x.job)} starts before ${e(x.predecessor)} finishes.</div>`),...(summary.overdue.length?[`<div class="plan-warning">${ico('bell',15)} <b>${summary.overdue.length} past-due jobs</b> are not marked complete.</div>`]:[])];
 return `<div class="planning-intro"><div><strong>Baseline & dependency schedule</strong><p>Manual planned dates · finish-to-start logic · original baselines remain visible as dotted bars.</p></div><div class="row-actions">${button('◀ 4 weeks','gantt-prev','small')}${button('Today','gantt-today','small')}${button('4 weeks ▶','gantt-next','small')}${summary.unscheduled.length?button('Fill example dates','fill-demo-dates','small',`data-id="${p.id}"`):''}${button('Capture baseline','capture-baseline','small primary',`data-id="${p.id}"`)}</div></div><div class="plan-kpis"><div><strong>${summary.planned}/${summary.total}</strong><span>Jobs with start and finish</span></div><div><strong>${summary.unscheduled.length}</strong><span>Unscheduled jobs</span></div><div><strong>${summary.conflicts.length}</strong><span>Dependency clashes</span></div><div><strong>${summary.slipped.length}</strong><span>Finish dates past baseline</span></div></div>${p.baseline?`<div class="baseline-note">${ico('check',14)} Baseline captured ${day(p.baseline.capturedAt)} · dotted bars show original plan. Capture again only when you intentionally rebaseline.</div>`:''}<div class="gantt-scroll"><div class="gantt-chart">${header}${content}</div></div><div class="gantt-legend"><span><i class="gantt-key planned"></i> Planned work</span><span><i class="gantt-key baseline"></i> Baseline</span><span><i class="gantt-key completion"></i> Completed</span><span><i class="gantt-key issue"></i> Clash</span><span>◆ finish only</span></div>${alerts.slice(0,8).join('')}<p class="planning-foot">Scheduling conflicts are warnings rather than automatic date changes. Critical-path calculations and resource levelling require a later verified planning engine.</p>`;
}
function projectMaterials(p){
 const rows=materialReadiness(data,p.id),gaps=rows.filter(r=>r.estimatedGap>0);const moneyAtRisk=gaps.reduce((sum,r)=>sum+r.estimatedGap*Number(r.part?.cost||0),0);
 return `<div class="planning-intro"><div><strong>Legacy V0.3 materials forecast</strong><p>Historical BOM estimates are preserved. Use Project procurement for the current assembly requirements, project reservations and purchase orders.</p></div><div class="row-actions">${button('Current project procurement','project-tab','small primary',`data-id="procurement"`)}${button('View purchasing','nav','small',`data-id="purchasing"`)}${button('Legacy BOM','project-tab','small',`data-id="bom"`)}</div></div><div class="plan-kpis"><div><strong>${rows.length}</strong><span>BOM lines</span></div><div><strong>${gaps.length}</strong><span>Potential shortfall lines</span></div><div><strong>${money(moneyAtRisk)}</strong><span>Estimated uncovered value</span></div><div><strong>${rows.reduce((sum,r)=>sum+r.incoming,0)}</strong><span>Items on open POs</span></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Part / assembly</th><th>Remaining need</th><th>Unreserved stores</th><th>On project POs</th><th>Uncovered estimate</th><th>Suggested action</th></tr></thead><tbody>${rows.map(r=>{const s=data.sections.find(x=>x.id===r.sectionId)?.name||'Unassigned assembly';return `<tr><td><strong>${e(r.part?.code||'Unknown')}</strong><small style="display:block">${e(r.part?.name||'Missing part')} · ${e(s)}</small></td><td>${number(r.quantityOutstanding)}</td><td>${number(r.freeStock)}</td><td>${number(r.incoming)}</td><td>${badge(String(r.estimatedGap),r.estimatedGap?'red':'green')}</td><td>${r.estimatedGap?'Check sourcing / ordering':'Material forecast covered'}</td></tr>`}).join('')||'<tr><td colspan="6">No BOM requirements</td></tr>'}</tbody></table></div><div class="planning-foot">Forecast only: stores quantities can be shared across projects; this view does not reserve stock, allocate incoming orders or certify availability. Production must use transactional reservations.</div>`;
}

function taskItem(t){return `<div class="task-item"><button class="task-bullet ${t.status==='Done'?'done':''}" data-action="toggle-task" data-id="${t.id}" aria-label="Toggle task completion">${t.status==='Done'?ico('check',12):''}</button><div class="details"><strong>${e(t.title)}</strong><small>${e(t.assignee)} · Due ${day(t.due)}</small></div><span class="tag ${e(t.department.toLowerCase())}">${e(t.department)}</span>${badge(t.status)}${button('Edit','edit-task','small',`data-id="${t.id}"`)}</div>`}

function projectBom(p){const rows=active(data.bom).filter(b=>b.projectId===p.id);return `<div class="v41-notice">Historical V0.3 BOM register. New purchasing, allocations and shortages use the assembly E-BOM. To add requirements for procurement, open the Project procurement tab. This legacy table is kept for backward compatibility.</div><div class="toolbar"><span class="subtle">Project-specific part requirements and stock</span><div class="spacer"></div>${button(`${ico('plus')} Add BOM part`,'add-bom','small primary',`data-project="${p.id}"`)}${button('Manage inventory '+ico('external'),'nav','small',`data-id="inventory"`)}</div><div class="table-wrap"><table class="table"><thead><tr><th>Part number</th><th>Description</th><th>Required</th><th>Reserved</th><th>Issued</th><th>To source</th><th></th></tr></thead><tbody>${rows.map(b=>{const x=findPart(b.partId);return `<tr><td><strong class="mono">${e(x?.code)}</strong></td><td>${e(x?.name)}</td><td>${number(b.required)}</td><td>${number(b.reserved)}</td><td>${number(b.issued)}</td><td>${badge(String(Math.max(0,b.required-b.reserved-b.issued)),b.required>b.reserved+b.issued?'amber':'green')}</td><td><div class="row-actions">${button('Edit','edit-bom','small',`data-id="${b.id}"`)}${button('Archive','archive-record','small danger',`data-kind="bom" data-id="${b.id}"`)}</div></td></tr>`}).join('')||'<tr><td colspan="7" class="subtle">No BOM items assigned</td></tr>'}</tbody></table></div>`}

function projectDocuments(p){const docs=active(data.documents).filter(d=>d.projectId===p.id);return `<div class="toolbar"><span class="subtle">Revision-aware document register · demo metadata only</span><div class="spacer"></div>${button(`${ico('plus')} Add document`,'open-document-modal','small',`data-project="${p.id}"`)}</div><div class="table-wrap"><table class="table"><thead><tr><th>Document</th><th>Revision</th><th>Type</th><th>Visibility</th><th>Updated</th><th>Manage</th></tr></thead><tbody>${docs.map(d=>`<tr><td>${ico('file')} <strong>${e(d.title)}</strong></td><td>${e(d.rev)}</td><td>${e(d.type)}</td><td>${badge(d.visibility==='customer'?'Published':'Internal',d.visibility==='customer'?'green':'gray')}</td><td>${day(d.date)}</td><td><div class="row-actions">${button('Edit','edit-document','small',`data-id="${d.id}"`)}${button('Archive','archive-record','small danger',`data-kind="documents" data-id="${d.id}"`)}</div></td></tr>`).join('')||'<tr><td colspan="6" class="subtle">No documents</td></tr>'}</tbody></table></div>`}
function projectPublishing(p){const u=active(data.updates).filter(x=>x.projectId===p.id);return `<div class="toolbar"><div class="subtle">Never automatically expose internal jobs to customers</div><div class="spacer"></div>${button(`${ico('plus')} Draft update`,'open-update-modal','small',`data-project="${p.id}"`)}</div><div class="card-body" style="padding-top:4px">${u.map(x=>`<div class="approval-row"><div><strong>${e(x.title)}</strong><small>${e(x.kind)} · ${e(x.description)}</small></div><div class="row-actions">${badge(x.status==='published'?'Published':'Draft',x.status==='published'?'green':'purple')}${x.status==='draft'?button('Edit','edit-update','small',`data-id="${x.id}"`):''}${x.status==='draft'?button('Publish','publish','small primary',`data-id="${x.id}"`):''}${x.status==='published'?button('Withdraw','withdraw-update','small danger',`data-id="${x.id}"`):''}${x.status==='draft'?button('Archive','archive-record','small danger',`data-kind="updates" data-id="${x.id}"`):''}</div></div>`).join('')||'<div class="empty">No updates yet</div>'}<p class="form-hint">Publishing here updates only the local demo customer preview. Production requires a separate allowlisted customer representation and verified permissions.</p></div>`}
function tasksPage(){const project=ui.taskProject||'all';const filtered=active(data.tasks).filter(t=>allActiveProjects().some(p=>p.id===t.projectId)&&(ui.dept==='All'||t.department===ui.dept)&&(project==='all'||t.projectId===project));
  const projectFilter=`<select class="filter-select" data-filter="taskProject"><option value="all">All projects</option>${allActiveProjects().map(p=>`<option value="${p.id}" ${project===p.id?'selected':''}>${e(p.code)} — ${e(p.name)}</option>`).join('')}</select>`;
  const deptFilter=`<select class="filter-select" data-filter="dept">${['All','Office','Workshop','Purchasing','Quality'].map(d=>`<option ${ui.dept===d?'selected':''}>${d}</option>`).join('')}</select>`;
  const headTools=`${button(`${ico('plus')} New job`,'open-task-modal','primary')}`;
  const cols=[['Backlog','Backlog'],['Ready','Ready'],['In progress','In progress'],['Blocked','Blocked'],['Inspection','Inspection'],['Done','Done']];
  const board=`<div class="kanban">${cols.map(([status,label])=>{const list=filtered.filter(t=>t.status===status);return `<div class="kanban-col"><div class="kanban-head"><strong>${label}</strong><span class="pill no-dot gray">${list.length}</span></div>${list.map(t=>`<div class="task-card"><div class="row-actions" style="float:right">${button(ico('more',14),'edit-task','small',`data-id="${t.id}" title="Edit job" aria-label="Edit ${e(t.title)}"`)}</div><strong>${e(t.title)}</strong><p>${e(findProject(t.projectId)?.code)} · ${e(t.assignee)}</p><div class="task-footer"><span class="tag ${e(t.department.toLowerCase())}">${e(t.department)}</span><select class="filter-select" style="max-width:120px;min-height:29px;padding:5px" data-task-status="${t.id}" aria-label="Change task status">${cols.map(([val])=>`<option value="${val}" ${t.status===val?'selected':''}>${val}</option>`).join('')}</select></div></div>`).join('')||'<div class="subtle" style="padding:12px 4px">No jobs</div>'}</div>`}).join('')}</div>`;
  const rows=filtered.map(t=>`<tr><td><b>${e(t.title)}</b><div class="subtle">${e(findProject(t.projectId)?.code)}</div></td><td>${e(t.department)}</td><td>${e(t.assignee)}</td><td>${badge(t.status)}</td><td>${day(t.due)}</td><td><select data-task-status="${t.id}" class="filter-select" style="max-width:150px">${cols.map(([v])=>`<option value="${v}" ${t.status===v?'selected':''}>${v}</option>`).join('')}</select></td><td><div class="row-actions">${button('Edit','edit-task','small',`data-id="${t.id}"`)}${button('Archive','archive-record','small danger',`data-kind="tasks" data-id="${t.id}"`)}</div></td></tr>`).join('');
  return head('Workshop & office jobs','Assignable work across engineering, production, purchasing and quality.',headTools)+`<div class="card"><div class="toolbar">${projectFilter}${deptFilter}<div class="spacer"></div><div class="segmented">${button('Board','task-board',`small ${ui.taskView==='board'?'active':''}`)}${button('List','task-list',`small ${ui.taskView==='list'?'active':''}`)}</div></div><div class="card-body">${ui.taskView==='board'?board:`<div class="table-wrap"><table class="table"><thead><tr><th>Job</th><th>Department</th><th>Assigned</th><th>Status</th><th>Due</th><th>Update</th><th>Edit / archive</th></tr></thead><tbody>${rows}</tbody></table></div>`}</div></div>`;
}
function purchasingPage(){const orders=active(data.orders),open=orders.filter(o=>o.status!=='Received');const total=orders.reduce((s,o)=>s+o.items.reduce((x,l)=>x+Number(l.quantity)*Number(l.unitCost),0),0);
  return head('Purchasing','Supplier orders, open commitments and materials due for the workshop.',button(`${ico('plus')} New purchase order`,'open-po-modal','primary'))+`<div class="kpis"><div class="kpi"><div><div class="kpi-label">Purchase orders</div><div class="kpi-value">${orders.length}</div><div class="kpi-note">All tracked orders</div></div><div class="kpi-icon">${ico('purchasing')}</div></div><div class="kpi"><div><div class="kpi-label">Open orders</div><div class="kpi-value">${open.length}</div><div class="kpi-note">Awaiting goods</div></div><div class="kpi-icon">${ico('clock')}</div></div><div class="kpi"><div><div class="kpi-label">Order value</div><div class="kpi-value" style="font-size:23px">${money(total)}</div><div class="kpi-note">Demonstration purchases</div></div><div class="kpi-icon">${ico('finance')}</div></div><div class="kpi"><div><div class="kpi-label">Partially received</div><div class="kpi-value">${orders.filter(o=>o.status==='Part received').length}</div><div class="kpi-note">Outstanding balances</div></div><div class="kpi-icon">${ico('inventory')}</div></div></div>${card('Purchase order register',`<div class="table-wrap"><table class="table"><thead><tr><th>Order</th><th>Supplier</th><th>Allocated project</th><th>Value</th><th>Delivery status</th><th>Action</th></tr></thead><tbody>${orders.map(o=>`<tr><td><b>${e(o.code)}</b><div class="subtle">${day(o.date)}</div></td><td>${e(o.supplier)}</td><td><span class="subtle">${e(findProject(o.projectId)?.code)}</span></td><td>${money(o.items.reduce((x,l)=>x+l.quantity*l.unitCost,0))}</td><td>${badge(o.status)}</td><td><div class="row-actions">${o.status==='Received'?'<span class="subtle">All received</span>':button('Receive remaining','receive-po','small',`data-id="${o.id}"`)}${button('Archive','archive-record','small danger',`data-kind="orders" data-id="${o.id}"`)}</div></td></tr>`).join('')}</tbody></table></div>`,'','Receiving an order adds its outstanding quantity into local demo stock')}`;
}
function inventoryPage(){const low=active(data.parts).filter(p=>availableStock(p)<=p.min);const rows=active(data.parts).map(p=>`<tr><td><strong class="mono">${e(p.code)}</strong><div class="subtle">${e(p.supplier)}</div></td><td><b>${e(p.name)}</b></td><td><span class="subtle">${e(p.location)}</span></td><td>${number(p.onHand)} ${e(p.unit)}</td><td>${number(p.reserved)}</td><td><strong class="${availableStock(p)<=p.min?'danger-text':'green-text'}">${number(availableStock(p))}</strong></td><td>${availableStock(p)<=p.min?badge('Reorder','amber'):badge('Healthy','green')}</td><td><div class="row-actions">${button('Move','stock-modal','small',`data-id="${p.id}"`)}${button('Edit','edit-part','small',`data-id="${p.id}"`)}${button('Archive','archive-record','small danger',`data-kind="parts" data-id="${p.id}"`)}</div></td></tr>`).join('');
  return head('Parts & inventory','A joined-up view of quantities, reservations, stores and shortages.',button(`${ico('plus')} New part`,'add-part','primary')+button('Stock movement','stock-modal','small'))+`<div class="kpis"><div class="kpi"><div><div class="kpi-label">Part SKUs</div><div class="kpi-value">${data.parts.length}</div><div class="kpi-note">Stock catalogue</div></div><div class="kpi-icon">${ico('inventory')}</div></div><div class="kpi"><div><div class="kpi-label">Below reorder level</div><div class="kpi-value">${low.length}</div><div class="kpi-note">Available stock</div></div><div class="kpi-icon">${ico('clock')}</div></div><div class="kpi"><div><div class="kpi-label">Reserved units</div><div class="kpi-value">${number(data.parts.reduce((s,p)=>s+p.reserved,0))}</div><div class="kpi-note">Allocated to projects</div></div><div class="kpi-icon">${ico('projects')}</div></div><div class="kpi"><div><div class="kpi-label">Inventory value</div><div class="kpi-value" style="font-size:22px">${money(data.parts.reduce((s,p)=>s+p.onHand*p.cost,0))}</div><div class="kpi-note">At reference demo cost</div></div><div class="kpi-icon">${ico('finance')}</div></div></div>${card('Stock register',`<div class="table-wrap"><table class="table"><thead><tr><th>Part</th><th>Description</th><th>Location</th><th>On hand</th><th>Reserved</th><th>Available</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`,'','Available stock = on hand − reservations')}<div style="height:18px"></div>${card('Recent movements',`<div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Part</th><th>Movement</th><th>Quantity</th><th>By</th></tr></thead><tbody>${data.movements.slice(0,8).map(m=>`<tr><td>${day(m.date)}</td><td>${e(findPart(m.partId)?.code)}</td><td>${badge(m.type)}</td><td class="mono">${number(m.quantity)}</td><td>${e(m.actor)}</td></tr>`).join('')}</tbody></table></div>`)}`;
}
function customersPage(){const detail=ui.customerDetail?findOrg(ui.customerDetail):null;return head('Customers & access','Set up customer companies once, then grant projects and manage people.',button(`${ico('plus')} Add customer`,'open-customer-modal','primary'))+`<div class="customer-grid" style="margin-bottom:20px">${active(data.organizations).map(org=>{const projects=activeOrgProjects(org.id),members=data.members.filter(m=>m.orgId===org.id);return `<div class="org-card"><div class="org-header"><div class="org-logo" style="background:${e(org.accent)}">${e(org.logo)}</div><div><h3>${e(org.name)}</h3><span class="subtle">${e(org.contact)} · ${e(org.code)}</span></div></div><p>${projects.length} separate customer project${projects.length!==1?'s':''}, each with its own access controls.</p><div class="org-stats"><div><strong>${projects.length}</strong><span>Projects</span></div><div><strong>${members.length}</strong><span>People</span></div>${button('Manage '+ico('chevron'),'customer-detail','small',`data-id="${org.id}"`)}${button('Edit','edit-customer','small',`data-id="${org.id}"`)}${button('Archive','archive-record','small danger',`data-kind="organizations" data-id="${org.id}"`)}</div></div>`}).join('')}</div>${detail&&!detail.archivedAt?customerDetail(detail):''}`}
function customerDetail(org){const members=active(data.members).filter(m=>m.orgId===org.id),projects=activeOrgProjects(org.id);return card(`${org.name} · customer team`, `<div class="toolbar"><span class="subtle">Customer admins can only delegate pre-granted project scopes in the future secure portal.</span><div class="spacer"></div>${button(`${ico('plus')} Add team member`,'invite-modal','small',`data-org="${org.id}"`)}</div><div class="table-wrap"><table class="table"><thead><tr><th>Person</th><th>Role</th><th>Project access</th><th>Status</th></tr></thead><tbody>${members.map(m=>`<tr><td><b>${e(m.name)}</b><div class="subtle">${e(m.email)}</div></td><td>${badge(m.role,'purple')}</td><td>${m.projects.map(id=>`<span class="tag">${e(findProject(id)?.code||id)}</span>`).join(' ')}</td><td>${badge(m.status||'Active','green')}</td></tr>`).join('')||'<tr><td colspan="4">No team members yet.</td></tr>'}</tbody></table></div><div class="card-body"><div class="subtle">Authorised projects: ${projects.map(p=>e(p.code)).join(', ')||'None'}</div></div>`);
}
function clientPage(){let projection=clientProjection(data,ui.clientOrg,ui.clientProject);if(!projection){ui.clientOrg=data.organizations[0]?.id;ui.clientProject=data.projects.find(p=>p.orgId===ui.clientOrg)?.id;projection=clientProjection(data,ui.clientOrg,ui.clientProject)}
  const org=projection?.organization,p=projection?.project;const options=projection?.projects||[];
  const selectors=`<div class="client-switch"><span class="pill purple">${ico('eye',13)} Client preview</span>${customerSelect(ui.clientOrg,'data-filter="clientOrg"')}<select class="filter-select" data-filter="clientProject">${options.map(q=>`<option value="${q.id}" ${p?.id===q.id?'selected':''}>${e(q.name)}</option>`).join('')}</select><div class="spacer"></div>${button(`${ico('plus')} Invite customer staff`,'invite-modal','small',`data-org="${org.id}"`)}</div>`;
  if(!p)return head('Customer portal','Preview exactly which types of information a customer should see.')+selectors+`<div class="empty">This customer has no projects.</div>`;
  const stages=['Discovery','Design','Manufacture','Assembly','Delivery'];let current=['Discovery','Engineering','Design','Manufacturing','Assembly','Commissioning','Testing','Delivery'].indexOf(p.phase);if(current<0)current=2;const phaseIndex=p.phase==='Manufacturing'?2:p.phase==='Assembly'?3:p.phase==='Delivery'?4:p.phase==='Engineering'?1:2;
  const preview=`<div class="client-banner" style="--customer:${e(org.accent)}"><div style="z-index:1;position:relative"><span class="client-badge">${e(org.name)} · PROJECT ACCESS</span><h2>${e(p.name)}</h2><p>${e(p.description)}</p><div class="timeline-steps">${stages.map((x,i)=>`<span class="timeline-step ${i<phaseIndex?'passed':i===phaseIndex?'current':''}"><b>${i<phaseIndex?ico('check',13):i+1}</b>${x}</span>`).join('')}</div></div><div class="client-delivery"><small>Target delivery</small><strong>${day(p.delivery)}</strong>${badge('In progress','green')}</div></div>`;
  const nav=[['updates','Progress updates'],['approvals','Approvals'],['files','Shared files'],['messages','Conversation'],['people','People & access']];
  const content=ui.clientTab==='updates'?clientUpdates(projection):ui.clientTab==='approvals'?clientApprovals(projection):ui.clientTab==='files'?clientFiles(projection):ui.clientTab==='messages'?clientMessages(projection):clientPeople(projection);
  return head('Customer portal preview','A separate, carefully curated view for each customer — not an internal dashboard.')+selectors+`<div class="client-notice">${ico('shield',15)} <strong>Demonstration preview only.</strong> Published records below are explicitly selected. The data is stored locally in this browser; production-grade customer isolation requires Supabase authentication and database security.</div><div class="client-shell" style="--customer:${e(org.accent)}">${preview}<div class="card"><div class="tabs">${nav.map(([key,label])=>`<button class="${ui.clientTab===key?'active':''}" data-action="client-tab" data-id="${key}">${label}${key==='approvals'?` <span class="count-dot">${projection.approvals.filter(a=>a.status==='Pending').length}</span>`:''}</button>`).join('')}</div><div class="card-body">${content}</div></div></div>`;
}
function clientUpdates(pr){return `<div class="grid-even" style="margin-bottom:6px"><div><div class="split-header"><b>Published project progress</b><b style="color:var(--green)">${pct(pr.project.publishedProgress)}%</b></div>${meter(pr.project.publishedProgress,'green')}<p class="form-hint">This number is a customer-approved snapshot, not the raw internal task average.</p></div><div><div class="split-header"><b>Latest milestones</b><span class="subtle">${pr.updates.length} published</span></div><div class="subtle">Updates and individual component status appear only after Sim-Worx publishes them.</div></div></div><h3 style="font:800 14px Manrope;margin:20px 0 12px">Progress journal</h3>${pr.updates.length?pr.updates.map(u=>`<div class="update-card"><div class="split-header">${badge(u.kind,'purple')}<span class="date">${day(u.publishedAt)}</span></div><h4>${e(u.title)}</h4><p>${e(u.description)}</p>${u.part?`<div class="subtle" style="margin-top:10px">Related component: ${e(u.part)}</div>`:''}</div>`).join(''):`<div class="empty">${ico('file')}<strong>Updates coming soon</strong><p>Published project milestones will appear here.</p></div>`}`}
function clientApprovals(pr){return pr.approvals.length?pr.approvals.map(a=>`<div class="approval-row"><div><strong>${e(a.title)}</strong><small>${e(a.kind)} · ${e(a.revision)} · Requested ${day(a.requested)}</small><small>Decision due ${day(a.due)}</small></div><div class="approval-actions">${a.status==='Pending'?`${button('Approve','decide-approval','small primary',`data-id="${a.id}" data-decision="Approved"`)}${button('Request changes','decide-approval','small',`data-id="${a.id}" data-decision="Changes requested"`)}`:badge(a.status)}</div></div>`).join('')+'<p class="form-hint">Demo decisions are recorded in your browser only. They are not digital signatures and do not contact Sim-Worx.</p>':'<div class="empty">No approval requests for this project.</div>'}
function clientFiles(pr){return `<div class="split-header"><div><b>Authorised project documents</b><div class="subtle" style="margin-top:4px">Only customer-published document metadata is displayed.</div></div>${button(`${ico('upload')} Add document`,'open-client-document-modal','small')}</div>${pr.documents.map(d=>`<div class="approval-row"><div style="display:flex;gap:12px;align-items:center">${ico('file',23)}<div><strong>${e(d.title)}</strong><small>${e(d.type)} · Revision ${e(d.rev)} · ${day(d.date)}</small></div></div>${badge('Shared','green')}</div>`).join('')||'<div class="empty">No shared documents</div>'}<p class="form-hint">File uploads and downloads will use private storage once the approved backend is connected. The demo does not save file bytes.</p>`}
function clientMessages(pr){return `<div class="column">${pr.messages.map(m=>`<div class="update-card" style="background:${m.author.startsWith('Sim-Worx')?'var(--violet2)':'var(--panel2)'}"><b style="font-size:11px">${e(m.author)}</b><span class="subtle" style="float:right">${day(m.at)}</span><p style="margin-top:10px">${e(m.text)}</p></div>`).join('')||'<p class="subtle">Start a conversation with the project team.</p>'}<form data-form="message" class="column"><div class="field"><label for="message-text">New message</label><textarea id="message-text" name="text" required placeholder="Ask the project team a question..."></textarea></div><button class="btn primary" type="submit" style="align-self:flex-end">${ico('message')} Send demo message</button></form></div>`}
function clientPeople(pr){return `<div class="split-header"><b>People with access to this project</b>${button(`${ico('plus')} Invite staff`,'invite-modal','small',`data-org="${pr.organization.id}"`)}</div><div class="table-wrap"><table class="table"><thead><tr><th>Person</th><th>Role</th><th>Scope</th></tr></thead><tbody>${pr.members.map(m=>`<tr><td><b>${e(m.name)}</b><div class="subtle">${e(m.email)}</div></td><td>${badge(m.role,'purple')}</td><td><span class="tag">This project</span></td></tr>`).join('')}</tbody></table></div><p class="form-hint">Production invites will require verified identity and server-enforced delegation ceilings. No invitations are actually sent from the demo.</p>`}

function financePage(){
 const projects=allActiveProjects(),snapshots=projects.map(p=>({project:p,b:projectBudgetSnapshot(data,p.id)}));
 const sum=key=>snapshots.reduce((n,r)=>n+Number(r.b[key]||0),0),pending=snapshots.reduce((n,r)=>n+r.b.unconverted.length,0);
 const stats=[['Project budgets',sum('budget'),'Total internal allowances'],
  ['Actual & received',sum('actual'),'Manual expenses and received new POs'],
  ['Open commitments',sum('commitment'),'Other costs and outstanding new POs'],
  ['Budget headroom',sum('headroom'),'Forecast allowance remaining']];
 const rows=snapshots.map(({project:p,b})=>'<tr><td><b>'+e(p.name)+'</b><small style="display:block">'+e(p.code)+'</small></td>'+
  '<td>'+money(b.budget)+'</td><td>'+money(b.actual)+'</td><td>'+money(b.commitment)+'</td>'+
  '<td>'+money(b.forecast)+'</td><td class="'+(b.overBudget?'danger-text':'green-text')+'"><b>'+money(b.headroom)+'</b>'+
  (b.unconverted.length?'<small style="display:block">FX pending</small>':'')+'</td>'+
  '<td>'+button('Manage','project-open','small','data-id="'+p.id+'"')+'</td></tr>').join('');
 return head('Project financials','Track internal project budgets, actuals and future commitments.')+
  '<div class="client-notice">'+ico('shield')+' Internal-only demo planning figures. Customer preview cannot access these data.</div>'+
  (pending?'<p class="v42-budget-warning">'+pending+' foreign-currency order(s) are excluded until an EUR conversion is set in the project Budget tab.</p>':'')+
  '<div class="finance-stats">'+stats.map(([name,value,help])=>'<div class="finance-stat"><span>'+e(name)+'</span>'+
  '<strong>'+money(value)+'</strong><small>'+e(help)+'</small></div>').join('')+'</div>'+
  card('Budget status by project',
   '<div class="table-wrap"><table class="table"><thead><tr><th>Project</th><th>Budget</th><th>Actual</th>'+
   '<th>Committed</th><th>Forecast</th><th>Headroom</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>',
   '','The new purchasing ledger supplements manually entered historic costs; foreign currencies require an explicit exchange rate.');
}
function reportsPage(){const rows=allActiveProjects().map(p=>{const prog=taskProgress(p.id,data.tasks);const done=data.tasks.filter(t=>t.projectId===p.id&&t.status==='Done').length;return `<div class="bar-group"><div class="bar-label"><span>${e(p.name)}</span><span>${prog}% · ${done} completed</span></div>${meter(prog)}</div>`}).join('');const states=['Done','In progress','Ready','Blocked','Inspection','Backlog'];const counts=states.map(s=>active(data.tasks).filter(t=>t.status===s&&allActiveProjects().some(p=>p.id===t.projectId)).length);const max=Math.max(...counts,1);
  return head('Reports & progress','See workload, completed jobs and project milestones across customers.',button(`${ico('refresh')} Refresh view`,'refresh',''))+`<div class="grid-even">${card('Project completion',`<div class="card-body" style="padding-top:0">${rows}</div>`,'','Internal task-derived progress')}${card('Production job pipeline',`<div class="card-body" style="padding-top:0"><div class="report-chart"><div class="skeleton-chart">${counts.map((count,i)=>`<div class="bar" style="height:${Math.max(9,count/max*100)}%"><span>${e(states[i].split(' ')[0])}</span></div>`).join('')}</div></div><p class="form-hint">${data.tasks.length} tracked department jobs across ${data.projects.length} projects.</p></div>`,'','Task statuses across the workshop')}</div>${card('Recent audit history',`<div class="table-wrap"><table class="table"><thead><tr><th>Action</th><th>Description</th><th>Actor</th><th>Time</th></tr></thead><tbody>${data.audit.slice(0,20).map(a=>`<tr><td><b>${e(a.action)}</b></td><td>${e(a.detail)}</td><td>${e(a.actor)}</td><td>${day(a.at)}</td></tr>`).join('')}</tbody></table></div>`,'','Event records for this browser-based demo')}`;
}
function settingsPage(){return head('Workspace settings','Your Project Hub experience and development-stage safeguards.')+`<div class="grid-even">${card('Appearance',`<div class="card-body"><div class="split-header"><div><b>Display theme</b><p class="form-hint">Choose a clean, light workspace or dark mode.</p></div>${button(data.settings.theme==='light'?`${ico('moon')} Dark mode`:`${ico('sun')} Light mode`,'theme','soft')}</div></div>`)}${card('Demo environment',`<div class="card-body"><b>No production connection</b><p class="form-hint">Your changes are stored in this browser. There is no login, database connection, email provider, file upload storage or shared access. This demo is suitable for product evaluation only.</p>${button(`${ico('refresh')} Reset demo data`,'reset-demo','danger')}</div>`)}${card('Email delivery',`<div class="card-body"><b>Disabled by design</b><p class="form-hint">No sending account has been approved. Approval events and invitations remain in the on-screen demo. We will enable email only after isolating and verifying a no-additional-cost route.</p>${badge('Not configured','amber')}</div>`)}${card('Archive & restore',`<div class="card-body"><p class="form-hint">Archiving retains history and references. Restore records here; nothing is permanently deleted.</p>${['organizations','projects','sections','tasks','parts','bom','documents','members','updates','orders'].flatMap(kind=>data[kind].filter(row=>row.archivedAt).map(row=>`<div class="archive-row"><div><b>${e(row.title||row.name||row.code||row.id)}</b><small>${e(kind)} · ${day(row.archivedAt)}</small></div>${button('Restore','restore-record','small',`data-kind="${kind}" data-id="${row.id}"`)}</div>`)).join('')||'<div class="subtle">No archived records</div>'}</div>`)}${card('Production readiness',`<div class="card-body">${['Customer login & RLS','Private document storage','Secure staff invitations','Transactional stock allocation','Automated emails','Independent deployment'].map(x=>`<div class="pipeline-item"><span class="pipe-main"><strong>${e(x)}</strong></span>${badge('Pending','amber')}</div>`).join('')}</div>`,'','These features require a separately approved backend') }</div>`;
}
function optionList(entries,current){return entries.map(([val,label])=>`<option value="${e(val)}" ${val===current?'selected':''}>${e(label)}</option>`).join('')}
const field=(label,name,kind='text',value='',required=true,extra='')=>`<div class="field"><label for="form-${name}">${e(label)}</label><input id="form-${name}" name="${e(name)}" type="${kind}" value="${e(value)}" ${required?'required':''} ${extra}/></div>`;
const selectField=(label,name,options,current)=>`<div class="field"><label for="form-${name}">${e(label)}</label><select id="form-${name}" name="${e(name)}" required>${optionList(options,current)}</select></div>`;
const textareaField=(label,name,value='')=>`<div class="field full"><label for="form-${name}">${e(label)}</label><textarea id="form-${name}" name="${e(name)}">${e(value)}</textarea></div>`;
function modalContent(){const m=ui.modal||{};let title='Project Hub',form='',hint='',submit='Save';
  if(m.type==='project'){
    const record=m.id?findProject(m.id):null;title=record?'Edit project':'Create a new project';submit=record?'Save project':'Create project';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><div class="form-grid">${field('Project name','name','text',record?.name||'')}${selectField('Customer organisation','orgId',active(data.organizations).map(o=>[o.id,o.name]),record?.orgId||data.organizations[0]?.id).replace('<select ','<select '+(record?'disabled ':''))}${record?`<input type="hidden" name="orgId" value="${e(record.orgId)}"/>`:selectField('Project template','template',['Bespoke Simulator','King Air 360','DA62','Generic Cockpit','Motion Upgrade'].map(x=>[x,x]),'Bespoke Simulator')}${field('Target delivery','due','date',record?.due||'2027-06-30')}${field('Project budget (EUR)','budget','number',record?.budget??'0',true,'min="0" step="0.01"')}${field('Contract value (EUR)','contract','number',record?.contract??'0',true,'min="0" step="0.01"')}${field('Internal project lead','lead','text',record?.lead||'Sim-Worx Project Manager')}${record?selectField('Status','status',['Design','In production','On hold','Delivered'].map(x=>[x,x]),record.status):''}${record?selectField('Current phase','phase',['Discovery','Engineering','Manufacturing','Assembly','Testing','Delivery'].map(x=>[x,x]),record.phase):''}${textareaField('Project scope / summary','description',record?.description||'')}</div>`;
    hint='The chosen template generates a separate project section hierarchy. Every project has its own customer and scope.';
  }else if(m.type==='customer'){
    const record=m.id?findOrg(m.id):null;title=record?'Edit customer organisation':'Create customer organisation';submit=record?'Save customer':'Add customer';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><div class="form-grid">${field('Company name','name','text',record?.name||'')}${field('Customer code','code','text',record?.code||'')}${field('Country / location','contact','text',record?.contact||'')}${field('Brand colour','accent','color',record?.accent||'#5369c4')}</div>`;
    hint='New customer organisations are independent. Additional staff and projects can be added after creation.';
  }else if(m.type==='task'){
    const record=m.id?data.tasks.find(t=>t.id===m.id):null;title=record?'Edit department job':'Assign a new department job';submit=record?'Save job':'Create job';const projectId=record?.projectId||m.project||ui.project||allActiveProjects()[0]?.id;const sections=active(data.sections).filter(x=>x.projectId===projectId);
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><div class="form-grid">${field('Job title','title','text',record?.title||'')}${selectField('Project','projectId',allActiveProjects().map(p=>[p.id,`${p.code} · ${p.name}`]),projectId).replace('name="projectId"',record?'name="projectId" disabled':'name="projectId" data-filter="modalProject"')}${record?`<input type="hidden" name="projectId" value="${record.projectId}"/>`:''}${selectField('Work section','sectionId',sections.map(s=>[s.id,s.name]),record?.sectionId||m.section||sections[0]?.id)}${selectField('Department','department',['Office','Workshop','Purchasing','Quality'].map(x=>[x,x]),record?.department||'Workshop')}${field('Assigned to','assignee','text',record?.assignee||'Unassigned')}${selectField('Priority','priority',['Normal','High','Critical'].map(x=>[x,x]),record?.priority||'Normal')}${selectField('Status','status',['Backlog','Ready','In progress','Blocked','Inspection','Done','Cancelled'].map(x=>[x,x]),record?.status||'Backlog')}${field('Planned start (optional)','start','date',record?.start||'',false)}${field('Planned finish','due','date',record?.due||today())}${selectField('Parent job (optional)','parentId',[['','None'],...active(data.tasks).filter(t=>t.projectId===projectId&&t.id!==record?.id&&t.sectionId===(record?.sectionId||m.section||sections[0]?.id)).map(t=>[t.id,t.title])],record?.parentId||m.parent||'').replace(' required>','>')}<div class="field full"><label for="form-predecessors">Predecessor jobs (Ctrl/Cmd-click for more than one)</label><select id="form-predecessors" name="predecessors" multiple size="4">${active(data.tasks).filter(t=>t.projectId===projectId&&t.id!==record?.id).map(t=>`<option value="${e(t.id)}" ${predecessorIds(record||{}).includes(t.id)?'selected':''}>${e(t.title)}</option>`).join('')}</select></div></div>`;
    hint='Dates are manually planned. Predecessors must be complete before work proceeds. The Gantt chart flags conflicts instead of silently moving dates.';
  }else if(m.type==='section'){
    const record=m.id?data.sections.find(x=>x.id===m.id):null;title=record?'Edit project section':'New project section';submit=record?'Save section':'Add section';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><input type="hidden" name="projectId" value="${e(record?.projectId||m.project||ui.project)}"/><div class="form-grid">${field('Section name','name','text',record?.name||'')}${field('Progress weighting (%)','weight','number',record?.weight??20,true,'min="0" max="100" step="1"')}</div>`;
    hint='Use sections for cockpit, visual systems, motion, avionics, testing or another major workstream.';
  }else if(m.type==='part'){
    const record=m.id?findPart(m.id):null;title=record?'Edit stock part':'Create stock part';submit=record?'Save part':'Add part';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><div class="form-grid">${field('SKU / part number','code','text',record?.code||'')}${field('Description','name','text',record?.name||'')}${field('Unit (ea, m, kg...)','unit','text',record?.unit||'ea')}${field('Supplier','supplier','text',record?.supplier||'',false)}${field('Stores location','location','text',record?.location||'',false)}${field('Minimum available stock','min','number',record?.min??0,true,'min="0" step="1"')}${field('Reference cost (EUR)','cost','number',record?.cost??0,true,'min="0" step="0.01"')}</div>`;
    hint='New stock parts start at zero quantity. Use the stock movement ledger to receive or issue units.';
  }else if(m.type==='bom'){
    const record=m.id?data.bom.find(x=>x.id===m.id):null;const projectId=record?.projectId||m.project||ui.project;
    title=record?'Edit BOM requirement':'Add part to project BOM';submit=record?'Save requirement':'Add BOM part';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><input type="hidden" name="projectId" value="${e(projectId)}"/><div class="form-grid">${selectField('Part','partId',active(data.parts).map(p=>[p.id,`${p.code} · ${p.name}`]),record?.partId||active(data.parts)[0]?.id).replace('<select ','<select '+(record?'disabled ':''))}${record?`<input type="hidden" name="partId" value="${record.partId}"/>`:''}${selectField('Assembly / project section','sectionId', [['','Not assigned'],...active(data.sections).filter(x=>x.projectId===projectId).map(x=>[x.id,x.name])],record?.sectionId||'').replace(' required>','>')}${field('Required quantity','required','number',record?.required??1,true,'min="1" step="1"')}</div>`;
    hint='A BOM requirement does not automatically reserve or receive stock.';
  }else if(m.type==='stock'){
    title='Record stock movement';submit='Record movement';const partId=m.id||data.parts[0]?.id;
    form=`<div class="form-grid">${selectField('Part','partId',data.parts.map(p=>[p.id,`${p.code} · ${p.name}`]),partId)}${selectField('Movement type','type',[['receipt','Receive into stores'],['issue','Issue from stores'],['adjust-in','Positive adjustment'],['adjust-out','Negative adjustment']],'receipt')}${field('Quantity','quantity','number','1',true,'min="1" step="1"')}</div>`;
    hint='Inventory movements are recorded in local demo history. Stock cannot become negative through the demo controls.';
  }else if(m.type==='po'){
    title='New purchase order';submit='Create PO';
    form=`<div class="form-grid">${selectField('Project','projectId',data.projects.map(p=>[p.id,`${p.code} · ${p.name}`]),ui.project)}${selectField('Part','partId',data.parts.map(p=>[p.id,`${p.code} · ${p.name}`]),data.parts[0]?.id)}${field('Supplier','supplier','text','')}${field('Quantity','quantity','number','1',true,'min="1" step="1"')}${field('Price each (EUR)','unitCost','number','0',true,'min="0" step="0.01"')}</div>`;
    hint='One-line purchase orders are available in this demonstration. Multi-line purchasing and partial deliveries are planned for the secure backend.';
  }else if(m.type==='invite'){
    title='Add customer staff';submit='Create demo invitation';const orgId=m.org||ui.clientOrg;const projects=activeOrgProjects(orgId);
    form=`<input type="hidden" name="orgId" value="${e(orgId)}"/><div class="form-grid">${field('Full name','name')}${field('Work email','email','email')}${selectField('Client role','role',['Client Viewer','Client Engineer','Client Approver','Client Lead'].map(x=>[x,x]),'Client Viewer')}${selectField('Project access','projectId',projects.map(p=>[p.id,p.name]),projects[0]?.id)}</div>`;
    hint='This is a mock invitation only; no email is sent. Production permissions will be restricted to the customer admin’s delegated project ceilings.';
  }else if(m.type==='update'){
    const record=m.id?data.updates.find(x=>x.id===m.id):null;title=record?'Edit customer progress draft':'Prepare customer progress update';submit=record?'Save changes':'Save draft';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><input type="hidden" name="projectId" value="${e(record?.projectId||m.project||ui.project)}"/><div class="form-grid">${field('Public update title','title','text',record?.title||'')}${selectField('Update category','kind',['Milestone','Component','Manufacturing','Quality','Delivery'].map(x=>[x,x]),record?.kind||'Milestone')}${field('Related component','part','text',record?.part||'',false)}${textareaField('Customer-facing summary','description',record?.description||'')}</div>`;
    hint='Drafts remain internal. A separate publish action is required before customers can see an update.';
  }else if(m.type==='document'||m.type==='client-document'){
    const client=m.type==='client-document';const record=m.id?data.documents.find(d=>d.id===m.id):null;title=record?'Edit document register':client?'Customer drawing / document':'Register internal document';submit='Save document metadata';
    form=`<input type="hidden" name="recordId" value="${e(record?.id||'')}"/><input type="hidden" name="projectId" value="${e(record?.projectId||(client?ui.clientProject:(m.project||ui.project)))}"/><div class="form-grid">${field('Document name','title','text',record?.title||'')}${field('Revision','rev','text',record?.rev||'A')}${selectField('Document category','type',['PDF drawing','Inspection report','Photo','CAD file','Other document'].map(x=>[x,x]),record?.type||'PDF drawing')}${!client?selectField('Visibility','visibility',[['internal','Internal only'],['customer','Published to client']],record?.visibility||'internal'):''}</div>`;
    hint='Only descriptive metadata is saved locally. No document bytes are uploaded. Secure uploads require authenticated private storage.';
  }else if(m.type==='notifications'){
    title='Notifications';submit='Close';form=`<div>${data.notifications.map(n=>`<div class="approval-row"><div><strong>${e(n.text)}</strong><small>${day(n.date)}</small></div>${badge(n.read?'Read':'New',n.read?'gray':'purple')}</div>`).join('')||'<p class="subtle">No notifications</p>'}</div>`;
  }
  return `<div class="modal-backdrop" role="presentation" data-action="dismiss-modal"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-header"><h2 id="modal-title">${e(title)}</h2><button class="circle-btn" type="button" data-action="close-modal" aria-label="Close modal">${ico('close')}</button></div><form data-form="${e(m.type)}"><div class="modal-body">${form}${hint?`<p class="form-hint">${e(hint)}</p>`:''}</div><div class="form-foot">${button('Cancel','close-modal')}${m.type==='notifications'?button('Mark all read','mark-read','primary'):`<button class="btn primary" type="submit">${e(submit)} ${ico('arrow')}</button>`}</div></form></div></div>`;
}
function openModal(type,details={}){ui.modal={type,...details};render()}
function closeModal(){ui.modal=null;render()}
function changePage(page){ui.page=page;ui.modal=null;render()}
function exportWbs(projectId){
  const project=findProject(projectId);if(!project)throw Error('Project not found');
  const headings=['WBS','Section','Job','Department','Assigned to','Priority','Status','Planned start','Planned finish','Predecessor jobs'];
  const rows=[headings];active(data.sections).filter(s=>s.projectId===project.id).forEach((sec,i)=>{
    rows.push([`${i+1}.0`,sec.name,'','','','','','','','']);
    const visited=new Set();let index=0;
    const visit=(task,wbs,depth)=>{if(visited.has(task.id)||depth>12)return;visited.add(task.id);
      rows.push([wbs,sec.name,task.title,task.department,task.assignee,task.priority,task.status,task.start||'',task.due,predecessorIds(task).map(id=>data.tasks.find(t=>t.id===id)?.title||id).join('; ')]);
      active(data.tasks).filter(t=>t.parentId===task.id).forEach((child,k)=>visit(child,`${wbs}.${k+1}`,depth+1));
    };
    active(data.tasks).filter(t=>t.sectionId===sec.id&&!t.parentId).forEach(t=>visit(t,`${i+1}.${++index}`,0));
  });
  const csv=rows.map(row=>row.map(value=>'"'+String(value??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}));
  const a=document.createElement('a');a.href=url;a.download=`${project.code}-WBS.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
}
function handleAction(el){const action=el.dataset.action,id=el.dataset.id;
 if(action?.startsWith('mfg-')){try{handleManufacturingAction(data,ui,el,window.confirm);persist();render();toast('Manufacturing demo updated locally');}catch(err){toast(err.message||'Manufacturing action failed',true)}return;}

 if(action==='v42-new-part'){ui.partReturnProject=ui.project;openModal('part');return;}
 if(action==='v42-edit-master'){ui.partReturnProject=ui.project;openModal('part',{id});return;}
 if(action?.startsWith('v41-')||action?.startsWith('v42-material-')){
   try{
     if(action==='v41-backup'){
       const payload=createWorkspaceBackup(data),url=URL.createObjectURL(new Blob([payload],{type:'application/json'}));
       const link=document.createElement('a');link.href=url;link.download='SimWorx_Project_Hub_Backup_V0.4.2_'+today()+'.json';
       document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
       toast('JSON workspace backup downloaded · keep it private');return;
     }
     if(action==='v41-restore'){document.getElementById('v41-restore-file')?.click();return;}
     const changed=handleMaterialsAction(data,ui,el,window.confirm);
     if(changed!=='dom'){persist();render();toast('Procurement updated locally');}
   }catch(err){toast(err.message||'Procurement action failed',true)}
   return;
 }

 try{switch(action){
  case 'nav':changePage(id);break;
  case 'project-open':ui.page='projects';ui.project=id;ui.projectTab='structure';ui.showProjectList=false;render();document.getElementById('project-detail')?.scrollIntoView({behavior:'smooth',block:'start'});break;
  case 'project-tab':ui.projectTab=id;render();break;
  case 'v42-toggle-project-list':ui.showProjectList=!ui.showProjectList;render();break;
  case 'client-tab':ui.clientTab=id;render();break;
  case 'task-board':ui.taskView='board';render();break;
  case 'task-list':ui.taskView='list';render();break;
  case 'department-open':ui.dept=id;ui.page='tasks';render();break;
  case 'open-project-modal':openModal('project');break;
  case 'edit-project':openModal('project',{id});break;
  case 'edit-customer':openModal('customer',{id});break;
  case 'edit-task':openModal('task',{id});break;
  case 'add-subtask':{const t=data.tasks.find(x=>x.id===id);if(t)openModal('task',{project:t.projectId,parent:t.id,section:t.sectionId});break;}
  case 'add-section':openModal('section',{project:el.dataset.project||ui.project});break;
  case 'edit-section':openModal('section',{id});break;
  case 'add-part':openModal('part');break;
  case 'edit-part':openModal('part',{id});break;
  case 'add-bom':openModal('bom',{project:el.dataset.project||ui.project});break;
  case 'edit-bom':openModal('bom',{id});break;
  case 'edit-document':openModal('document',{id});break;
  case 'edit-update':openModal('update',{id});break;
  case 'open-task-modal':openModal('task',{project:el.dataset.project||ui.project});break;
  case 'open-customer-modal':openModal('customer');break;
  case 'open-po-modal':openModal('po');break;
  case 'stock-modal':openModal('stock',{id});break;
  case 'invite-modal':openModal('invite',{org:el.dataset.org||ui.clientOrg});break;
  case 'open-update-modal':openModal('update',{project:el.dataset.project||ui.project});break;
  case 'open-document-modal':openModal('document',{project:el.dataset.project||ui.project});break;
  case 'open-client-document-modal':openModal('client-document');break;
  case 'customer-detail':ui.customerDetail=id;render();break;
  case 'close-modal':case 'dismiss-modal':ui.partReturnProject=null;closeModal();break;
  case 'theme':data.settings.theme=data.settings.theme==='light'?'dark':'light';persist();render();break;
  case 'toggle-task':{const t=data.tasks.find(x=>x.id===id);if(t){setTaskStatus(data,id,t.status==='Done'?'Ready':'Done');persist();render();toast('Job status saved locally')}break;}
  case 'publish':{if(confirm('Publish this exact draft to the customer preview?')){publishUpdate(data,id);persist();render();toast('Update published to the demo customer portal')}break;}
  case 'withdraw-update':{const u=data.updates.find(x=>x.id===id);if(u?.status==='published'&&confirm('Withdraw this customer update? It will no longer be visible in the demo portal.')){u.status='withdrawn';audit('Customer publication withdrawn',u.title);persist();render();toast('Publication withdrawn')}break;}
  case 'archive-record':{const kind=el.dataset.kind,row=data[kind]?.find(x=>x.id===id);if(row&&confirm(`Archive ${row.name||row.title||row.code||id}?\nThe record stays in history and may be restored in Settings.`)){archiveRecord(data,kind,id);persist();render();toast('Record archived · restore from Settings')}break;}
  case 'restore-record':{restoreRecord(data,el.dataset.kind,id);persist();render();toast('Record restored');break;}
  case 'export-wbs':{exportWbs(id);toast('Project work breakdown exported as CSV');break;}
  case 'gantt-prev':ui.ganttOffset-=1;render();break;
  case 'gantt-next':ui.ganttOffset+=1;render();break;
  case 'gantt-today':ui.ganttOffset=0;render();break;
  case 'fill-demo-dates':{if(!confirm('Generate illustrative seven-day dates for unscheduled jobs that have finish dates? This changes only local fictional demo records; it is not a real project plan.'))break;let changed=0;active(data.tasks).filter(t=>t.projectId===id&&!t.start&&t.due).forEach(t=>{updateTaskPlan(data,t.id,{start:shiftDate(t.due,-7)});changed++;});persist();render();toast(`${changed} illustrative dates added to demo jobs`);break;}
  case 'capture-baseline':{const project=findProject(id);if(project?.baseline&&!confirm('Replace the existing schedule baseline with the current plan? Original baseline dates will be overwritten in this browser demo.'))break;const baseline=captureBaseline(data,id);persist();render();toast(`Baseline saved for ${Object.keys(baseline.jobs).length} jobs`);break;}

  case 'decide-approval':{decideApproval(data,id,el.dataset.decision);notify(`Client decision: ${el.dataset.decision}`);persist();render();toast(`Decision recorded: ${el.dataset.decision}`);break;}
  case 'receive-po':{receiveOrder(data,id);persist();render();toast('Outstanding purchase order quantities received into stock');break;}
  case 'notifications':openModal('notifications');break;
  case 'mark-read':data.notifications.forEach(x=>x.read=true);persist();closeModal();toast('Notifications marked as read');break;
  case 'reset-demo':if(confirm('Reset all local demo records and changes? This cannot be undone.')){data=seed();persist();ui.page='overview';ui.project='p1';ui.clientOrg='noah';ui.clientProject='p1';render();toast('Demo reset to original sample data')}break;
  case 'refresh':render();toast('Dashboard refreshed from local demo records');break;
  }}catch(err){toast(err.message||'Unable to complete this action',true)}
}
function formHandler(form){const fd=new FormData(form);const get=n=>String(fd.get(n)||'').trim();const type=form.dataset.form;
 if(type?.startsWith('mfg-')){try{handleManufacturingSubmit(data,ui,form);persist();render();toast('Manufacturing record saved locally');}catch(err){toast(err.message||'Manufacturing form failed',true)}return;}
 if(type?.startsWith('v41-')||type==='v42-material-edit'){try{handleMaterialsSubmit(data,ui,form);persist();render();toast('Procurement saved locally');}catch(err){toast(err.message||'Procurement form failed',true)}return;}
 if(type==='v42-budget'||type==='v42-exchange'){
   try{
     if(type==='v42-budget')updateProjectBudget(data,{projectId:get('projectId'),budget:get('budget'),spent:get('spent'),committed:get('committed')});
     else setPurchaseExchangeRate(data,{orderId:get('orderId'),eurExchangeRate:get('eurExchangeRate')});
     persist();render();toast('Budget updated locally');
   }catch(err){toast(err.message||'Budget update failed',true)}
   return;
 }
 try{switch(type){
  case 'project':{
    const existing=get('recordId');const record=saveProject(data,{id:existing||null,orgId:get('orgId'),name:get('name'),template:get('template'),status:get('status'),phase:get('phase'),due:get('due'),budget:get('budget'),contract:get('contract'),lead:get('lead'),description:get('description')});
    if(!existing){const names=record.template==='DA62'?['Cockpit','Visual system','Avionics','Testing & delivery']:record.template==='Motion Upgrade'?['Mechanics','Control systems','Installation & test']:['Cockpit & structure','Control loading','Visual system','Avionics & software','Testing & delivery'];names.forEach(name=>{const sec=saveSection(data,{projectId:record.id,name,weight:Math.round(100/names.length)});
      saveAssembly(data,{projectId:record.id,sectionId:sec.id,name,code:name.toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,28),perParentQty:1,buildQty:1,owner:'Unassigned',status:'Design'});
    });}
    ui.project=record.id;ui.page='projects';ui.projectTab='structure';break;
  }
  case 'customer':{
    const org=saveOrganization(data,{id:get('recordId')||null,name:get('name'),code:get('code'),contact:get('contact'),accent:get('accent')});ui.customerDetail=org.id;ui.page='customers';break;
  }
  case 'task':{
    const record=saveTask(data,{id:get('recordId')||null,projectId:get('projectId'),sectionId:get('sectionId'),title:get('title'),department:get('department'),assignee:get('assignee'),priority:get('priority'),status:get('status'),due:get('due'),parentId:get('parentId'),blockedBy:null,predecessors:fd.getAll('predecessors').map(String),start:get('start')});ui.project=record.projectId;ui.page='projects';if(!['register','schedule'].includes(ui.projectTab))ui.projectTab='structure';break;
  }
  case 'section':{
    const record=saveSection(data,{id:get('recordId')||null,projectId:get('projectId'),name:get('name'),weight:get('weight')});ui.project=record.projectId;ui.page='projects';ui.projectTab='structure';break;
  }
  case 'part':{
    savePart(data,{id:get('recordId')||null,code:get('code'),name:get('name'),unit:get('unit'),supplier:get('supplier'),location:get('location'),min:get('min'),cost:get('cost')});if(ui.partReturnProject){ui.project=ui.partReturnProject;ui.page='projects';ui.projectTab='procurement';ui.partReturnProject=null;}else ui.page='inventory';break;
  }
  case 'bom':{
    const record=saveBomLine(data,{id:get('recordId')||null,projectId:get('projectId'),partId:get('partId'),required:get('required'),sectionId:get('sectionId')});ui.project=record.projectId;ui.page='projects';ui.projectTab='bom';break;
  }
  case 'stock':{stockMove(data,{partId:get('partId'),quantity:get('quantity'),type:get('type')});ui.page='inventory';break;}
  case 'po':{const part=findPart(get('partId'));if(!part)throw Error('Part not found');const q=Number(get('quantity')),cost=Number(get('unitCost'));if(!Number.isInteger(q)||q<1||!Number.isFinite(cost)||cost<0)throw Error('Check order quantity and unit cost');const code=`PO-${new Date().getFullYear().toString().slice(2)}${String(data.orders.length+120).padStart(4,'0')}`;data.orders.unshift({id:uid('po'),code,projectId:get('projectId'),supplier:get('supplier')||part.supplier,date:today(),status:'Awaiting delivery',items:[{partId:part.id,quantity:q,received:0,unitCost:cost}]});audit('Purchase order created',code);ui.page='purchasing';break;}
  case 'invite':{clientInvite(data,{orgId:get('orgId'),name:get('name'),email:get('email'),role:get('role'),projectIds:[get('projectId')]});ui.page=ui.page==='client'?'client':'customers';break;}
  case 'update':{const id=get('recordId');const record=id?data.updates.find(x=>x.id===id):null;if(record){if(record.status!=='draft')throw Error('Only drafts can be edited');Object.assign(record,{title:get('title'),kind:get('kind'),part:get('part'),description:get('description')});audit('Customer draft updated',record.title)}else{data.updates.unshift({id:uid('u'),projectId:get('projectId'),title:get('title'),kind:get('kind'),part:get('part'),description:get('description'),date:today(),status:'draft'});audit('Customer update drafted',get('title'))}ui.page='projects';ui.project=get('projectId');ui.projectTab='publishing';break;}
  case 'document':case 'client-document':{const record=get('recordId')?data.documents.find(x=>x.id===get('recordId')):null;const visibility=type==='client-document'?'internal':get('visibility');if(record){if(record.rev!==get('rev')&&record.visibility==='customer')record.visibility='internal';Object.assign(record,{title:get('title'),rev:get('rev'),type:get('type'),visibility:record.rev!==get('rev')?'internal':visibility,date:today()});audit('Document metadata updated',record.title)}else{data.documents.unshift({id:uid('d'),projectId:get('projectId'),title:get('title'),rev:get('rev'),type:get('type'),visibility,date:today()});audit(type==='client-document'?'Customer document metadata submitted':'Document registered',get('title'))}break;}
  case 'message':{const text=get('text');if(!text)throw Error('Enter a message');data.messages.push({id:uid('msg'),projectId:ui.clientProject,author:'Customer demo user',text,visibility:'customer',at:new Date().toISOString()});audit('Customer message drafted',`Message in ${ui.clientProject}`);break;}
  default:return;
 }ui.modal=null;persist();render();toast(type==='invite'?'Demo invitation recorded — no email sent':type==='client-document'?'Metadata saved for internal review — no file uploaded':'Saved to local demo workspace');
 }catch(err){toast(err.message||'Unable to save form',true)}
}

function settingsPageV041(){
  return settingsPage() + '<div class="card v41-backup"><div class="card-head"><h2>Workspace backup & restore · V0.4.2</h2></div><p>Download all current demo records, including projects, assemblies, stock, supplier orders, delivery tracking, attachments and internal illustrative financial data. Keep the file private. A restore replaces records in this browser only after confirmation.</p><div class="v41-backup-actions">'+button('Download JSON backup','v41-backup','primary')+button('Restore JSON backup','v41-restore')+'</div><input id="v41-restore-file" type="file" accept=".json,application/json" aria-label="Choose workspace JSON backup"><p>Local browser demo only. There is no cloud sync or production database.</p></div>';
}
function restoreBackupFile(file){
 if(!file)return;
 if(file.size>10000000){toast('Backup exceeds the 10 MB limit',true);return;}
 file.text().then(content=>{
   const candidate=parseWorkspaceBackup(content);
   if(!confirm('Replace ALL Project Hub demo records in this browser with the selected backup? Save your current backup first if needed.'))return;
   try{localStorage.setItem(STORAGE_KEY,JSON.stringify(candidate));}
   catch(err){throw Error('Could not save restored records. Existing data remains unchanged. '+err.message);}
   data=candidate;ui.page='overview';ui.project=data.projects.find(p=>!p.archivedAt)?.id||'';
   ui.materialPO=null;ui.materialOrderEditor=false;render();toast('Workspace restored from JSON backup');
 }).catch(err=>toast('Cannot restore: '+String(err.message||err),true));
}

document.addEventListener('click',ev=>{const el=ev.target.closest('[data-action]');if(el){if(el.dataset.action==='dismiss-modal'&&ev.target!==el)return;handleAction(el)}});
document.addEventListener('submit',ev=>{const form=ev.target.closest('form[data-form]');if(form){ev.preventDefault();formHandler(form)}});
document.addEventListener('change',ev=>{try{const el=ev.target;
 if(el.dataset.v41Proof){handleMaterialsProof(data,el,()=>{persist();render();toast('Proof document saved locally')},message=>toast(message,true));return;}
 if(el.id==='v41-restore-file'){restoreBackupFile(el.files?.[0]);return;}
 if(el.dataset.v42Delivery){updateOrderStage(data,el.dataset.v42Delivery,el.value);persist();render();toast('Delivery stage changed; stock unchanged');return;}
 const filter=el.dataset.filter;
 if(filter==='v42-project'){ui.project=el.value;ui.projectTab='structure';ui.materialEditOccurrence=null;render();return;}
 if(filter==='v42-project-extra'){if(el.value){ui.projectTab=el.value;render();}return;}
 if(filter==='v41-project'){ui.procurementProject=el.value;ui.materialPO=null;ui.materialOrderEditor=false;render();return;}
 if(filter==='mfgProject'){ui.project=el.value;ui.mfgAssemblyId=null;ui.mfgEditor=null;render()}
 else if(filter==='dept'){ui.dept=el.value;render()}
 else if(filter==='taskProject'){ui.taskProject=el.value;render()}
 else if(filter==='clientOrg'){ui.clientOrg=el.value;ui.clientProject=activeOrgProjects(el.value)[0]?.id;ui.clientTab='updates';render()}
 else if(filter==='clientProject'){ui.clientProject=el.value;render()}
 else if(filter==='modalProject'){ui.modal.project=el.value;render()}
 else if(el.dataset.inlineTask){const t=data.tasks.find(x=>x.id===el.dataset.inlineTask&&!x.archivedAt);if(!t)throw Error('Job missing');const field=el.dataset.field;if(field==='status')setTaskStatus(data,t.id,el.value);else if(['start','due'].includes(field))updateTaskPlan(data,t.id,{[field]:el.value});else if(['assignee','department','priority'].includes(field))saveTask(data,{...t,[field]:el.value});else throw Error('Field not editable');persist();render();toast('Work register updated locally')}
 else if(el.dataset.taskStatus){setTaskStatus(data,el.dataset.taskStatus,el.value);persist();render();toast('Job status updated')}
}catch(err){toast(err.message||'Cannot update status',true);render()}});
document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&ui.modal)closeModal()});
render();