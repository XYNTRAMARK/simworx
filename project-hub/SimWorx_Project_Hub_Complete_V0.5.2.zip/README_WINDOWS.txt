SIM-WORX PROJECT HUB V0.5.2 — OFFLINE OWNER TEST BUILD
17 November 2026

1. Right-click the ZIP in Windows File Explorer and choose Extract All.
2. Move the extracted HTML into a permanent folder.
3. Double-click the HTML and open it with current Microsoft Edge or Google Chrome.
4. Confirm the visible version label is V0.5.2.
5. Export a separate private JSON backup from the old version before opening real data.
6. Never share your private project workspace or financial documents on public GitHub.
7. This release is NOT approved for genuine high-value purchases.

Read release notes and owner acceptance checklist in project-hub/docs/ on
branch feature/project-hub-v0.5.2-safety-attention of XYNTRAMARK/simworx.
