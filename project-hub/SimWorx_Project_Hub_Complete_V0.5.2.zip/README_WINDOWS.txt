SIM-WORX PROJECT HUB V0.5.2 — OFFLINE OWNER TEST BUILD
17 November 2026

1. Right-click the ZIP in Windows File Explorer and select Extract All.
2. Move extracted HTML to a permanent folder, not the ZIP viewer/temp folder.
3. Open the HTML using current Chrome or Microsoft Edge; verify V0.5.2 in header.
4. Export a separate PRIVATE JSON backup of V0.5.1 before replacing local data.
5. Use fictional test records; this is NOT approved for high-value real purchases.
6. Protect all contracts, supplier invoices and backup photos. Never upload them to
   the public repository.
7. Read project-hub/docs/release-v052.md and OWNER_ACCEPTANCE_V052.md on branch
   feature/project-hub-v0.5.2-safety-attention at XYNTRAMARK/simworx.
